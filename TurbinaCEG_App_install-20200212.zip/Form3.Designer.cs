﻿namespace TurbinaCEG
{
    public partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        public void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.textBox58 = new System.Windows.Forms.TextBox();
            this.textBox59 = new System.Windows.Forms.TextBox();
            this.textBox60 = new System.Windows.Forms.TextBox();
            this.textBox61 = new System.Windows.Forms.TextBox();
            this.textBox62 = new System.Windows.Forms.TextBox();
            this.textBox63 = new System.Windows.Forms.TextBox();
            this.textBox64 = new System.Windows.Forms.TextBox();
            this.textBox65 = new System.Windows.Forms.TextBox();
            this.textBox66 = new System.Windows.Forms.TextBox();
            this.textBox67 = new System.Windows.Forms.TextBox();
            this.textBox68 = new System.Windows.Forms.TextBox();
            this.textBox69 = new System.Windows.Forms.TextBox();
            this.textBox70 = new System.Windows.Forms.TextBox();
            this.textBox71 = new System.Windows.Forms.TextBox();
            this.textBox72 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox73 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.textBox74 = new System.Windows.Forms.TextBox();
            this.textBox75 = new System.Windows.Forms.TextBox();
            this.textBox76 = new System.Windows.Forms.TextBox();
            this.textBox77 = new System.Windows.Forms.TextBox();
            this.textBox78 = new System.Windows.Forms.TextBox();
            this.textBox79 = new System.Windows.Forms.TextBox();
            this.textBox80 = new System.Windows.Forms.TextBox();
            this.textBox81 = new System.Windows.Forms.TextBox();
            this.textBox82 = new System.Windows.Forms.TextBox();
            this.textBox83 = new System.Windows.Forms.TextBox();
            this.textBox84 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.Vazao = new System.Windows.Forms.TextBox();
            this.Pres = new System.Windows.Forms.TextBox();
            this.Temp = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.Pulso_Tot = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Pulso_Vol = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Pulso_Min = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Fator = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.groupBox4);
            this.panel1.Location = new System.Drawing.Point(3, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(889, 299);
            this.panel1.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBox43);
            this.groupBox2.Controls.Add(this.textBox44);
            this.groupBox2.Controls.Add(this.textBox45);
            this.groupBox2.Controls.Add(this.textBox46);
            this.groupBox2.Controls.Add(this.textBox47);
            this.groupBox2.Controls.Add(this.textBox48);
            this.groupBox2.Controls.Add(this.textBox49);
            this.groupBox2.Controls.Add(this.textBox50);
            this.groupBox2.Controls.Add(this.textBox51);
            this.groupBox2.Controls.Add(this.textBox52);
            this.groupBox2.Controls.Add(this.textBox53);
            this.groupBox2.Controls.Add(this.textBox54);
            this.groupBox2.Controls.Add(this.textBox55);
            this.groupBox2.Controls.Add(this.textBox56);
            this.groupBox2.Controls.Add(this.textBox57);
            this.groupBox2.Controls.Add(this.textBox58);
            this.groupBox2.Controls.Add(this.textBox59);
            this.groupBox2.Controls.Add(this.textBox60);
            this.groupBox2.Controls.Add(this.textBox61);
            this.groupBox2.Controls.Add(this.textBox62);
            this.groupBox2.Controls.Add(this.textBox63);
            this.groupBox2.Controls.Add(this.textBox64);
            this.groupBox2.Controls.Add(this.textBox65);
            this.groupBox2.Controls.Add(this.textBox66);
            this.groupBox2.Controls.Add(this.textBox67);
            this.groupBox2.Controls.Add(this.textBox68);
            this.groupBox2.Controls.Add(this.textBox69);
            this.groupBox2.Controls.Add(this.textBox70);
            this.groupBox2.Controls.Add(this.textBox71);
            this.groupBox2.Controls.Add(this.textBox72);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.textBox73);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.textBox74);
            this.groupBox2.Controls.Add(this.textBox75);
            this.groupBox2.Controls.Add(this.textBox76);
            this.groupBox2.Controls.Add(this.textBox77);
            this.groupBox2.Controls.Add(this.textBox78);
            this.groupBox2.Controls.Add(this.textBox79);
            this.groupBox2.Controls.Add(this.textBox80);
            this.groupBox2.Controls.Add(this.textBox81);
            this.groupBox2.Controls.Add(this.textBox82);
            this.groupBox2.Controls.Add(this.textBox83);
            this.groupBox2.Controls.Add(this.textBox84);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Location = new System.Drawing.Point(534, 18);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(348, 275);
            this.groupBox2.TabIndex = 68;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Turbina Teste";
            // 
            // textBox43
            // 
            this.textBox43.Location = new System.Drawing.Point(288, 205);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(50, 20);
            this.textBox43.TabIndex = 67;
            this.textBox43.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox44
            // 
            this.textBox44.Location = new System.Drawing.Point(288, 179);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(50, 20);
            this.textBox44.TabIndex = 66;
            this.textBox44.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox45
            // 
            this.textBox45.Location = new System.Drawing.Point(288, 153);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(50, 20);
            this.textBox45.TabIndex = 65;
            this.textBox45.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox46
            // 
            this.textBox46.Location = new System.Drawing.Point(288, 125);
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(50, 20);
            this.textBox46.TabIndex = 64;
            this.textBox46.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox47
            // 
            this.textBox47.Location = new System.Drawing.Point(288, 99);
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(50, 20);
            this.textBox47.TabIndex = 63;
            this.textBox47.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox48
            // 
            this.textBox48.Location = new System.Drawing.Point(288, 73);
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new System.Drawing.Size(50, 20);
            this.textBox48.TabIndex = 62;
            this.textBox48.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox49
            // 
            this.textBox49.Location = new System.Drawing.Point(232, 205);
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new System.Drawing.Size(50, 20);
            this.textBox49.TabIndex = 61;
            this.textBox49.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox50
            // 
            this.textBox50.Location = new System.Drawing.Point(232, 179);
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(50, 20);
            this.textBox50.TabIndex = 60;
            this.textBox50.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox51
            // 
            this.textBox51.Location = new System.Drawing.Point(232, 153);
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(50, 20);
            this.textBox51.TabIndex = 59;
            this.textBox51.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox52
            // 
            this.textBox52.Location = new System.Drawing.Point(232, 125);
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(50, 20);
            this.textBox52.TabIndex = 58;
            this.textBox52.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox53
            // 
            this.textBox53.Location = new System.Drawing.Point(232, 99);
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(50, 20);
            this.textBox53.TabIndex = 57;
            this.textBox53.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox54
            // 
            this.textBox54.Location = new System.Drawing.Point(232, 73);
            this.textBox54.Name = "textBox54";
            this.textBox54.Size = new System.Drawing.Size(50, 20);
            this.textBox54.TabIndex = 56;
            this.textBox54.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox55
            // 
            this.textBox55.Location = new System.Drawing.Point(176, 205);
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(50, 20);
            this.textBox55.TabIndex = 55;
            this.textBox55.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox56
            // 
            this.textBox56.Location = new System.Drawing.Point(176, 179);
            this.textBox56.Name = "textBox56";
            this.textBox56.Size = new System.Drawing.Size(50, 20);
            this.textBox56.TabIndex = 54;
            this.textBox56.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox57
            // 
            this.textBox57.Location = new System.Drawing.Point(176, 153);
            this.textBox57.Name = "textBox57";
            this.textBox57.Size = new System.Drawing.Size(50, 20);
            this.textBox57.TabIndex = 53;
            this.textBox57.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox58
            // 
            this.textBox58.Location = new System.Drawing.Point(176, 125);
            this.textBox58.Name = "textBox58";
            this.textBox58.Size = new System.Drawing.Size(50, 20);
            this.textBox58.TabIndex = 52;
            this.textBox58.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox59
            // 
            this.textBox59.Location = new System.Drawing.Point(176, 99);
            this.textBox59.Name = "textBox59";
            this.textBox59.Size = new System.Drawing.Size(50, 20);
            this.textBox59.TabIndex = 51;
            this.textBox59.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox60
            // 
            this.textBox60.Location = new System.Drawing.Point(176, 73);
            this.textBox60.Name = "textBox60";
            this.textBox60.Size = new System.Drawing.Size(50, 20);
            this.textBox60.TabIndex = 50;
            this.textBox60.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox61
            // 
            this.textBox61.Location = new System.Drawing.Point(120, 205);
            this.textBox61.Name = "textBox61";
            this.textBox61.Size = new System.Drawing.Size(50, 20);
            this.textBox61.TabIndex = 49;
            this.textBox61.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox62
            // 
            this.textBox62.Location = new System.Drawing.Point(120, 179);
            this.textBox62.Name = "textBox62";
            this.textBox62.Size = new System.Drawing.Size(50, 20);
            this.textBox62.TabIndex = 48;
            this.textBox62.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox63
            // 
            this.textBox63.Location = new System.Drawing.Point(120, 153);
            this.textBox63.Name = "textBox63";
            this.textBox63.Size = new System.Drawing.Size(50, 20);
            this.textBox63.TabIndex = 47;
            this.textBox63.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox64
            // 
            this.textBox64.Location = new System.Drawing.Point(120, 125);
            this.textBox64.Name = "textBox64";
            this.textBox64.Size = new System.Drawing.Size(50, 20);
            this.textBox64.TabIndex = 46;
            this.textBox64.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox65
            // 
            this.textBox65.Location = new System.Drawing.Point(120, 99);
            this.textBox65.Name = "textBox65";
            this.textBox65.Size = new System.Drawing.Size(50, 20);
            this.textBox65.TabIndex = 45;
            this.textBox65.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox66
            // 
            this.textBox66.Location = new System.Drawing.Point(120, 73);
            this.textBox66.Name = "textBox66";
            this.textBox66.Size = new System.Drawing.Size(50, 20);
            this.textBox66.TabIndex = 44;
            this.textBox66.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox67
            // 
            this.textBox67.Location = new System.Drawing.Point(64, 205);
            this.textBox67.Name = "textBox67";
            this.textBox67.Size = new System.Drawing.Size(50, 20);
            this.textBox67.TabIndex = 43;
            this.textBox67.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox68
            // 
            this.textBox68.Location = new System.Drawing.Point(64, 179);
            this.textBox68.Name = "textBox68";
            this.textBox68.Size = new System.Drawing.Size(50, 20);
            this.textBox68.TabIndex = 42;
            this.textBox68.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox69
            // 
            this.textBox69.Location = new System.Drawing.Point(64, 153);
            this.textBox69.Name = "textBox69";
            this.textBox69.Size = new System.Drawing.Size(50, 20);
            this.textBox69.TabIndex = 41;
            this.textBox69.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox70
            // 
            this.textBox70.Location = new System.Drawing.Point(64, 125);
            this.textBox70.Name = "textBox70";
            this.textBox70.Size = new System.Drawing.Size(50, 20);
            this.textBox70.TabIndex = 40;
            this.textBox70.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox71
            // 
            this.textBox71.Location = new System.Drawing.Point(64, 99);
            this.textBox71.Name = "textBox71";
            this.textBox71.Size = new System.Drawing.Size(50, 20);
            this.textBox71.TabIndex = 39;
            this.textBox71.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox72
            // 
            this.textBox72.Location = new System.Drawing.Point(64, 73);
            this.textBox72.Name = "textBox72";
            this.textBox72.Size = new System.Drawing.Size(50, 20);
            this.textBox72.TabIndex = 38;
            this.textBox72.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label11.Location = new System.Drawing.Point(288, 20);
            this.label11.MinimumSize = new System.Drawing.Size(50, 2);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(50, 15);
            this.label11.TabIndex = 37;
            this.label11.Text = "100%";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox73
            // 
            this.textBox73.Location = new System.Drawing.Point(288, 47);
            this.textBox73.Name = "textBox73";
            this.textBox73.Size = new System.Drawing.Size(50, 20);
            this.textBox73.TabIndex = 36;
            this.textBox73.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label12.Location = new System.Drawing.Point(232, 20);
            this.label12.MinimumSize = new System.Drawing.Size(50, 2);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(50, 15);
            this.label12.TabIndex = 35;
            this.label12.Text = "70%";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label13.Location = new System.Drawing.Point(176, 20);
            this.label13.MinimumSize = new System.Drawing.Size(50, 2);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(50, 15);
            this.label13.TabIndex = 34;
            this.label13.Text = "50%";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label14.Location = new System.Drawing.Point(120, 20);
            this.label14.MinimumSize = new System.Drawing.Size(50, 2);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(50, 15);
            this.label14.TabIndex = 33;
            this.label14.Text = "30%";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label18.Location = new System.Drawing.Point(64, 20);
            this.label18.MinimumSize = new System.Drawing.Size(50, 2);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(50, 15);
            this.label18.TabIndex = 32;
            this.label18.Text = "20%";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox74
            // 
            this.textBox74.Location = new System.Drawing.Point(232, 47);
            this.textBox74.Name = "textBox74";
            this.textBox74.Size = new System.Drawing.Size(50, 20);
            this.textBox74.TabIndex = 31;
            this.textBox74.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox75
            // 
            this.textBox75.Location = new System.Drawing.Point(176, 47);
            this.textBox75.Name = "textBox75";
            this.textBox75.Size = new System.Drawing.Size(50, 20);
            this.textBox75.TabIndex = 30;
            this.textBox75.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox76
            // 
            this.textBox76.Location = new System.Drawing.Point(120, 47);
            this.textBox76.Name = "textBox76";
            this.textBox76.Size = new System.Drawing.Size(50, 20);
            this.textBox76.TabIndex = 29;
            this.textBox76.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox77
            // 
            this.textBox77.Location = new System.Drawing.Point(64, 47);
            this.textBox77.Name = "textBox77";
            this.textBox77.Size = new System.Drawing.Size(50, 20);
            this.textBox77.TabIndex = 28;
            this.textBox77.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox78
            // 
            this.textBox78.Location = new System.Drawing.Point(8, 205);
            this.textBox78.Name = "textBox78";
            this.textBox78.Size = new System.Drawing.Size(50, 20);
            this.textBox78.TabIndex = 27;
            this.textBox78.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox79
            // 
            this.textBox79.Location = new System.Drawing.Point(8, 179);
            this.textBox79.Name = "textBox79";
            this.textBox79.Size = new System.Drawing.Size(50, 20);
            this.textBox79.TabIndex = 26;
            this.textBox79.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox80
            // 
            this.textBox80.Location = new System.Drawing.Point(8, 153);
            this.textBox80.Name = "textBox80";
            this.textBox80.Size = new System.Drawing.Size(50, 20);
            this.textBox80.TabIndex = 25;
            this.textBox80.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox81
            // 
            this.textBox81.Location = new System.Drawing.Point(8, 125);
            this.textBox81.Name = "textBox81";
            this.textBox81.Size = new System.Drawing.Size(50, 20);
            this.textBox81.TabIndex = 21;
            this.textBox81.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox82
            // 
            this.textBox82.Location = new System.Drawing.Point(8, 99);
            this.textBox82.Name = "textBox82";
            this.textBox82.Size = new System.Drawing.Size(50, 20);
            this.textBox82.TabIndex = 19;
            this.textBox82.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox83
            // 
            this.textBox83.Location = new System.Drawing.Point(8, 73);
            this.textBox83.Name = "textBox83";
            this.textBox83.Size = new System.Drawing.Size(50, 20);
            this.textBox83.TabIndex = 17;
            this.textBox83.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox84
            // 
            this.textBox84.Location = new System.Drawing.Point(8, 47);
            this.textBox84.Name = "textBox84";
            this.textBox84.Size = new System.Drawing.Size(50, 20);
            this.textBox84.TabIndex = 14;
            this.textBox84.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label19.Location = new System.Drawing.Point(8, 20);
            this.label19.MinimumSize = new System.Drawing.Size(50, 2);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(50, 15);
            this.label19.TabIndex = 0;
            this.label19.Text = "10%";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.Vazao);
            this.groupBox1.Controls.Add(this.Pres);
            this.groupBox1.Controls.Add(this.Temp);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.Pulso_Tot);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.Pulso_Vol);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.Pulso_Min);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.Fator);
            this.groupBox1.Location = new System.Drawing.Point(3, 18);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(171, 275);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Itens";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(15, 232);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(88, 20);
            this.button3.TabIndex = 17;
            this.button3.Text = "Transferir";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(91, 17);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(70, 20);
            this.button2.TabIndex = 16;
            this.button2.Text = "Stop";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(15, 17);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(70, 20);
            this.button1.TabIndex = 15;
            this.button1.Text = "Start";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "10 %",
            "20 %",
            "30 %",
            "50 %",
            "70 %",
            "100 %"});
            this.comboBox1.Location = new System.Drawing.Point(111, 231);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(50, 21);
            this.comboBox1.TabIndex = 14;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // Vazao
            // 
            this.Vazao.Location = new System.Drawing.Point(111, 205);
            this.Vazao.Name = "Vazao";
            this.Vazao.Size = new System.Drawing.Size(50, 20);
            this.Vazao.TabIndex = 13;
            this.Vazao.Text = "0";
            this.Vazao.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pres
            // 
            this.Pres.Location = new System.Drawing.Point(111, 179);
            this.Pres.Name = "Pres";
            this.Pres.Size = new System.Drawing.Size(50, 20);
            this.Pres.TabIndex = 12;
            this.Pres.Text = "0";
            this.Pres.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Temp
            // 
            this.Temp.Location = new System.Drawing.Point(111, 153);
            this.Temp.Name = "Temp";
            this.Temp.Size = new System.Drawing.Size(50, 20);
            this.Temp.TabIndex = 11;
            this.Temp.Text = "0";
            this.Temp.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 125);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(95, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Pulsos Totalizados";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 99);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 13);
            this.label6.TabIndex = 9;
            this.label6.Text = "Pulsos por m3";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(12, 73);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(91, 13);
            this.label15.TabIndex = 8;
            this.label15.Text = "Pulsos por Minuto";
            // 
            // Pulso_Tot
            // 
            this.Pulso_Tot.Location = new System.Drawing.Point(111, 125);
            this.Pulso_Tot.Name = "Pulso_Tot";
            this.Pulso_Tot.Size = new System.Drawing.Size(50, 20);
            this.Pulso_Tot.TabIndex = 7;
            this.Pulso_Tot.Text = "0";
            this.Pulso_Tot.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 205);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Vazão m3/h";
            // 
            // Pulso_Vol
            // 
            this.Pulso_Vol.Location = new System.Drawing.Point(111, 99);
            this.Pulso_Vol.Name = "Pulso_Vol";
            this.Pulso_Vol.Size = new System.Drawing.Size(50, 20);
            this.Pulso_Vol.TabIndex = 5;
            this.Pulso_Vol.Text = "0";
            this.Pulso_Vol.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 179);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Pressão";
            // 
            // Pulso_Min
            // 
            this.Pulso_Min.Location = new System.Drawing.Point(111, 73);
            this.Pulso_Min.Name = "Pulso_Min";
            this.Pulso_Min.Size = new System.Drawing.Size(50, 20);
            this.Pulso_Min.TabIndex = 3;
            this.Pulso_Min.Text = "0";
            this.Pulso_Min.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 153);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Temperatura";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 46);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Fator K";
            // 
            // Fator
            // 
            this.Fator.Location = new System.Drawing.Point(111, 47);
            this.Fator.Name = "Fator";
            this.Fator.Size = new System.Drawing.Size(50, 20);
            this.Fator.TabIndex = 0;
            this.Fator.Text = "0";
            this.Fator.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.textBox37);
            this.groupBox4.Controls.Add(this.textBox38);
            this.groupBox4.Controls.Add(this.textBox39);
            this.groupBox4.Controls.Add(this.textBox40);
            this.groupBox4.Controls.Add(this.textBox41);
            this.groupBox4.Controls.Add(this.textBox42);
            this.groupBox4.Controls.Add(this.textBox31);
            this.groupBox4.Controls.Add(this.textBox32);
            this.groupBox4.Controls.Add(this.textBox33);
            this.groupBox4.Controls.Add(this.textBox34);
            this.groupBox4.Controls.Add(this.textBox35);
            this.groupBox4.Controls.Add(this.textBox36);
            this.groupBox4.Controls.Add(this.textBox25);
            this.groupBox4.Controls.Add(this.textBox26);
            this.groupBox4.Controls.Add(this.textBox27);
            this.groupBox4.Controls.Add(this.textBox28);
            this.groupBox4.Controls.Add(this.textBox29);
            this.groupBox4.Controls.Add(this.textBox30);
            this.groupBox4.Controls.Add(this.textBox19);
            this.groupBox4.Controls.Add(this.textBox20);
            this.groupBox4.Controls.Add(this.textBox21);
            this.groupBox4.Controls.Add(this.textBox22);
            this.groupBox4.Controls.Add(this.textBox23);
            this.groupBox4.Controls.Add(this.textBox24);
            this.groupBox4.Controls.Add(this.textBox13);
            this.groupBox4.Controls.Add(this.textBox14);
            this.groupBox4.Controls.Add(this.textBox15);
            this.groupBox4.Controls.Add(this.textBox16);
            this.groupBox4.Controls.Add(this.textBox17);
            this.groupBox4.Controls.Add(this.textBox18);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.textBox12);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.textBox11);
            this.groupBox4.Controls.Add(this.textBox10);
            this.groupBox4.Controls.Add(this.textBox9);
            this.groupBox4.Controls.Add(this.textBox8);
            this.groupBox4.Controls.Add(this.textBox1);
            this.groupBox4.Controls.Add(this.textBox2);
            this.groupBox4.Controls.Add(this.textBox3);
            this.groupBox4.Controls.Add(this.textBox4);
            this.groupBox4.Controls.Add(this.textBox5);
            this.groupBox4.Controls.Add(this.textBox6);
            this.groupBox4.Controls.Add(this.textBox7);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Location = new System.Drawing.Point(180, 18);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(348, 275);
            this.groupBox4.TabIndex = 9;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Turbina Master";
            // 
            // textBox37
            // 
            this.textBox37.Location = new System.Drawing.Point(288, 205);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(50, 20);
            this.textBox37.TabIndex = 67;
            this.textBox37.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox38
            // 
            this.textBox38.Location = new System.Drawing.Point(288, 179);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(50, 20);
            this.textBox38.TabIndex = 66;
            this.textBox38.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox39
            // 
            this.textBox39.Location = new System.Drawing.Point(288, 153);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(50, 20);
            this.textBox39.TabIndex = 65;
            this.textBox39.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox40
            // 
            this.textBox40.Location = new System.Drawing.Point(288, 125);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(50, 20);
            this.textBox40.TabIndex = 64;
            this.textBox40.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox41
            // 
            this.textBox41.Location = new System.Drawing.Point(288, 99);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(50, 20);
            this.textBox41.TabIndex = 63;
            this.textBox41.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox42
            // 
            this.textBox42.Location = new System.Drawing.Point(288, 73);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(50, 20);
            this.textBox42.TabIndex = 62;
            this.textBox42.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(232, 205);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(50, 20);
            this.textBox31.TabIndex = 61;
            this.textBox31.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(232, 179);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(50, 20);
            this.textBox32.TabIndex = 60;
            this.textBox32.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(232, 153);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(50, 20);
            this.textBox33.TabIndex = 59;
            this.textBox33.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox34
            // 
            this.textBox34.Location = new System.Drawing.Point(232, 125);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(50, 20);
            this.textBox34.TabIndex = 58;
            this.textBox34.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(232, 99);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(50, 20);
            this.textBox35.TabIndex = 57;
            this.textBox35.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox36
            // 
            this.textBox36.Location = new System.Drawing.Point(232, 73);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(50, 20);
            this.textBox36.TabIndex = 56;
            this.textBox36.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(176, 205);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(50, 20);
            this.textBox25.TabIndex = 55;
            this.textBox25.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(176, 179);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(50, 20);
            this.textBox26.TabIndex = 54;
            this.textBox26.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(176, 153);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(50, 20);
            this.textBox27.TabIndex = 53;
            this.textBox27.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(176, 125);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(50, 20);
            this.textBox28.TabIndex = 52;
            this.textBox28.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(176, 99);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(50, 20);
            this.textBox29.TabIndex = 51;
            this.textBox29.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(176, 73);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(50, 20);
            this.textBox30.TabIndex = 50;
            this.textBox30.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(120, 205);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(50, 20);
            this.textBox19.TabIndex = 49;
            this.textBox19.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(120, 179);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(50, 20);
            this.textBox20.TabIndex = 48;
            this.textBox20.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(120, 153);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(50, 20);
            this.textBox21.TabIndex = 47;
            this.textBox21.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(120, 125);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(50, 20);
            this.textBox22.TabIndex = 46;
            this.textBox22.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(120, 99);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(50, 20);
            this.textBox23.TabIndex = 45;
            this.textBox23.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(120, 73);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(50, 20);
            this.textBox24.TabIndex = 44;
            this.textBox24.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(64, 205);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(50, 20);
            this.textBox13.TabIndex = 43;
            this.textBox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(64, 179);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(50, 20);
            this.textBox14.TabIndex = 42;
            this.textBox14.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(64, 153);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(50, 20);
            this.textBox15.TabIndex = 41;
            this.textBox15.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(64, 125);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(50, 20);
            this.textBox16.TabIndex = 40;
            this.textBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(64, 99);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(50, 20);
            this.textBox17.TabIndex = 39;
            this.textBox17.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(64, 73);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(50, 20);
            this.textBox18.TabIndex = 38;
            this.textBox18.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label17.Location = new System.Drawing.Point(288, 20);
            this.label17.MinimumSize = new System.Drawing.Size(50, 2);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(50, 15);
            this.label17.TabIndex = 37;
            this.label17.Text = "100%";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(288, 47);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(50, 20);
            this.textBox12.TabIndex = 36;
            this.textBox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label16.Location = new System.Drawing.Point(232, 20);
            this.label16.MinimumSize = new System.Drawing.Size(50, 2);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(50, 15);
            this.label16.TabIndex = 35;
            this.label16.Text = "70%";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label10.Location = new System.Drawing.Point(176, 20);
            this.label10.MinimumSize = new System.Drawing.Size(50, 2);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(50, 15);
            this.label10.TabIndex = 34;
            this.label10.Text = "50%";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label9.Location = new System.Drawing.Point(120, 20);
            this.label9.MinimumSize = new System.Drawing.Size(50, 2);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(50, 15);
            this.label9.TabIndex = 33;
            this.label9.Text = "30%";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label7.Location = new System.Drawing.Point(64, 20);
            this.label7.MinimumSize = new System.Drawing.Size(50, 2);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 15);
            this.label7.TabIndex = 32;
            this.label7.Text = "20%";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(232, 47);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(50, 20);
            this.textBox11.TabIndex = 31;
            this.textBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(176, 47);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(50, 20);
            this.textBox10.TabIndex = 30;
            this.textBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(120, 47);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(50, 20);
            this.textBox9.TabIndex = 29;
            this.textBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(64, 47);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(50, 20);
            this.textBox8.TabIndex = 28;
            this.textBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(8, 205);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(50, 20);
            this.textBox1.TabIndex = 27;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(8, 179);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(50, 20);
            this.textBox2.TabIndex = 26;
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(8, 153);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(50, 20);
            this.textBox3.TabIndex = 25;
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(8, 125);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(50, 20);
            this.textBox4.TabIndex = 21;
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(8, 99);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(50, 20);
            this.textBox5.TabIndex = 19;
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(8, 73);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(50, 20);
            this.textBox6.TabIndex = 17;
            this.textBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(8, 47);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(50, 20);
            this.textBox7.TabIndex = 14;
            this.textBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label8.Location = new System.Drawing.Point(8, 20);
            this.label8.MinimumSize = new System.Drawing.Size(50, 2);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(50, 15);
            this.label8.TabIndex = 0;
            this.label8.Text = "10%";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(902, 331);
            this.Controls.Add(this.panel1);
            this.Name = "Form3";
            this.Text = "Form3";
            this.panel1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox Vazao;
        private System.Windows.Forms.TextBox Pres;
        private System.Windows.Forms.TextBox Temp;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox Pulso_Tot;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Pulso_Vol;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Pulso_Min;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Fator;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.TextBox textBox48;
        private System.Windows.Forms.TextBox textBox49;
        private System.Windows.Forms.TextBox textBox50;
        private System.Windows.Forms.TextBox textBox51;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.TextBox textBox54;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.TextBox textBox56;
        private System.Windows.Forms.TextBox textBox57;
        private System.Windows.Forms.TextBox textBox58;
        private System.Windows.Forms.TextBox textBox59;
        private System.Windows.Forms.TextBox textBox60;
        private System.Windows.Forms.TextBox textBox61;
        private System.Windows.Forms.TextBox textBox62;
        private System.Windows.Forms.TextBox textBox63;
        private System.Windows.Forms.TextBox textBox64;
        private System.Windows.Forms.TextBox textBox65;
        private System.Windows.Forms.TextBox textBox66;
        private System.Windows.Forms.TextBox textBox67;
        private System.Windows.Forms.TextBox textBox68;
        private System.Windows.Forms.TextBox textBox69;
        private System.Windows.Forms.TextBox textBox70;
        private System.Windows.Forms.TextBox textBox71;
        private System.Windows.Forms.TextBox textBox72;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox73;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBox74;
        private System.Windows.Forms.TextBox textBox75;
        private System.Windows.Forms.TextBox textBox76;
        private System.Windows.Forms.TextBox textBox77;
        private System.Windows.Forms.TextBox textBox78;
        private System.Windows.Forms.TextBox textBox79;
        private System.Windows.Forms.TextBox textBox80;
        private System.Windows.Forms.TextBox textBox81;
        private System.Windows.Forms.TextBox textBox82;
        private System.Windows.Forms.TextBox textBox83;
        private System.Windows.Forms.TextBox textBox84;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox8;
    }
}