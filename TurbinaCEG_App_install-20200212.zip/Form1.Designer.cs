﻿using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Threading;
using System.Windows.Forms.DataVisualization.Charting;

namespace SimpleModBusforPLC
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.portconnect = new System.Windows.Forms.Button();
            this.portname = new System.Windows.Forms.ComboBox();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.configuraçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fichaTécnicaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.comunicaçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sobreToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.GroupTeste = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label32 = new System.Windows.Forms.Label();
            this.Volume = new System.Windows.Forms.TextBox();
            this.Vazao_T100 = new System.Windows.Forms.TextBox();
            this.Pres_T100 = new System.Windows.Forms.TextBox();
            this.Temp_T100 = new System.Windows.Forms.TextBox();
            this.Pulso_Tot_T100 = new System.Windows.Forms.TextBox();
            this.Vol_Tot_T100 = new System.Windows.Forms.TextBox();
            this.Pulso_Min_T100 = new System.Windows.Forms.TextBox();
            this.Vazao_T70 = new System.Windows.Forms.TextBox();
            this.Pres_T70 = new System.Windows.Forms.TextBox();
            this.Temp_T70 = new System.Windows.Forms.TextBox();
            this.Pulso_Tot_T70 = new System.Windows.Forms.TextBox();
            this.Vol_Tot_T70 = new System.Windows.Forms.TextBox();
            this.Pulso_Min_T70 = new System.Windows.Forms.TextBox();
            this.Vazao_T50 = new System.Windows.Forms.TextBox();
            this.Pres_T50 = new System.Windows.Forms.TextBox();
            this.Temp_T50 = new System.Windows.Forms.TextBox();
            this.Pulso_Tot_T50 = new System.Windows.Forms.TextBox();
            this.Vol_Tot_T50 = new System.Windows.Forms.TextBox();
            this.Pulso_Min_T50 = new System.Windows.Forms.TextBox();
            this.Vazao_T30 = new System.Windows.Forms.TextBox();
            this.Pres_T30 = new System.Windows.Forms.TextBox();
            this.Temp_T30 = new System.Windows.Forms.TextBox();
            this.Pulso_Tot_T30 = new System.Windows.Forms.TextBox();
            this.Vol_Tot_T30 = new System.Windows.Forms.TextBox();
            this.Pulso_Min_T30 = new System.Windows.Forms.TextBox();
            this.Vazao_T20 = new System.Windows.Forms.TextBox();
            this.Pres_T20 = new System.Windows.Forms.TextBox();
            this.Temp_T20 = new System.Windows.Forms.TextBox();
            this.Pulso_Tot_T20 = new System.Windows.Forms.TextBox();
            this.Vol_Tot_T20 = new System.Windows.Forms.TextBox();
            this.Pulso_Min_T20 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.Fator_T100 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.Fator_T70 = new System.Windows.Forms.TextBox();
            this.Fator_T50 = new System.Windows.Forms.TextBox();
            this.Fator_T30 = new System.Windows.Forms.TextBox();
            this.Fator_T20 = new System.Windows.Forms.TextBox();
            this.Vazao_T10 = new System.Windows.Forms.TextBox();
            this.Pres_T10 = new System.Windows.Forms.TextBox();
            this.Temp_T10 = new System.Windows.Forms.TextBox();
            this.Pulso_Tot_T10 = new System.Windows.Forms.TextBox();
            this.Vol_Tot_T10 = new System.Windows.Forms.TextBox();
            this.Pulso_Min_T10 = new System.Windows.Forms.TextBox();
            this.Fator_T10 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.Restante = new System.Windows.Forms.TextBox();
            this.Vazao_T = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.Pres_T = new System.Windows.Forms.TextBox();
            this.Temp_T = new System.Windows.Forms.TextBox();
            this.Pulso_Tot_T = new System.Windows.Forms.TextBox();
            this.Vol_Tot_T = new System.Windows.Forms.TextBox();
            this.Pulso_Min_T = new System.Windows.Forms.TextBox();
            this.Fator_T = new System.Windows.Forms.TextBox();
            this.btnTransfer = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.btnStart = new System.Windows.Forms.Button();
            this.Percentual = new System.Windows.Forms.ComboBox();
            this.Vazao_M = new System.Windows.Forms.TextBox();
            this.Pres_M = new System.Windows.Forms.TextBox();
            this.Temp_M = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.Pulso_Tot_M = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.Vol_Tot_M = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.Pulso_Min_M = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.Fator_M = new System.Windows.Forms.TextBox();
            this.GroupMaster = new System.Windows.Forms.GroupBox();
            this.Vazao_M100 = new System.Windows.Forms.TextBox();
            this.Pres_M100 = new System.Windows.Forms.TextBox();
            this.Temp_M100 = new System.Windows.Forms.TextBox();
            this.Pulso_Tot_M100 = new System.Windows.Forms.TextBox();
            this.Vol_Tot_M100 = new System.Windows.Forms.TextBox();
            this.Pulso_Min_M100 = new System.Windows.Forms.TextBox();
            this.Vazao_M70 = new System.Windows.Forms.TextBox();
            this.Pres_M70 = new System.Windows.Forms.TextBox();
            this.Temp_M70 = new System.Windows.Forms.TextBox();
            this.Pulso_Tot_M70 = new System.Windows.Forms.TextBox();
            this.Vol_Tot_M70 = new System.Windows.Forms.TextBox();
            this.Pulso_Min_M70 = new System.Windows.Forms.TextBox();
            this.Vazao_M50 = new System.Windows.Forms.TextBox();
            this.Pres_M50 = new System.Windows.Forms.TextBox();
            this.Temp_M50 = new System.Windows.Forms.TextBox();
            this.Pulso_Tot_M50 = new System.Windows.Forms.TextBox();
            this.Vol_Tot_M50 = new System.Windows.Forms.TextBox();
            this.Pulso_Min_M50 = new System.Windows.Forms.TextBox();
            this.Vazao_M30 = new System.Windows.Forms.TextBox();
            this.Pres_M30 = new System.Windows.Forms.TextBox();
            this.Temp_M30 = new System.Windows.Forms.TextBox();
            this.Pulso_Tot_M30 = new System.Windows.Forms.TextBox();
            this.Vol_Tot_M30 = new System.Windows.Forms.TextBox();
            this.Pulso_Min_M30 = new System.Windows.Forms.TextBox();
            this.Vazao_M20 = new System.Windows.Forms.TextBox();
            this.Pres_M20 = new System.Windows.Forms.TextBox();
            this.Temp_M20 = new System.Windows.Forms.TextBox();
            this.Pulso_Tot_M20 = new System.Windows.Forms.TextBox();
            this.Vol_Tot_M20 = new System.Windows.Forms.TextBox();
            this.Pulso_Min_M20 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.Fator_M100 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.Fator_M70 = new System.Windows.Forms.TextBox();
            this.Fator_M50 = new System.Windows.Forms.TextBox();
            this.Fator_M30 = new System.Windows.Forms.TextBox();
            this.Fator_M20 = new System.Windows.Forms.TextBox();
            this.Vazao_M10 = new System.Windows.Forms.TextBox();
            this.Pres_M10 = new System.Windows.Forms.TextBox();
            this.Temp_M10 = new System.Windows.Forms.TextBox();
            this.Pulso_Tot_M10 = new System.Windows.Forms.TextBox();
            this.Vol_Tot_M10 = new System.Windows.Forms.TextBox();
            this.Pulso_Min_M10 = new System.Windows.Forms.TextBox();
            this.Fator_M10 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.timer_parada = new System.Windows.Forms.Timer(this.components);
            this.timer_corrida = new System.Windows.Forms.Timer(this.components);
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.StatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.TempoLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.aferiçaçãoDeVazãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.GroupTeste.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.GroupMaster.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // chart1
            // 
            this.chart1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chart1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(223)))), ((int)(((byte)(240)))));
            this.chart1.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.TopBottom;
            this.chart1.BackSecondaryColor = System.Drawing.Color.White;
            this.chart1.BorderlineColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(59)))), ((int)(((byte)(105)))));
            this.chart1.BorderlineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid;
            this.chart1.BorderSkin.SkinStyle = System.Windows.Forms.DataVisualization.Charting.BorderSkinStyle.Emboss;
            chartArea2.Area3DStyle.Inclination = 15;
            chartArea2.Area3DStyle.IsClustered = true;
            chartArea2.Area3DStyle.IsRightAngleAxes = false;
            chartArea2.Area3DStyle.Perspective = 10;
            chartArea2.Area3DStyle.Rotation = 10;
            chartArea2.Area3DStyle.WallWidth = 0;
            chartArea2.AxisX.LabelStyle.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold);
            chartArea2.AxisX.LabelStyle.Format = "hh:mm:ss";
            chartArea2.AxisX.LabelStyle.Interval = 10D;
            chartArea2.AxisX.LabelStyle.IntervalType = System.Windows.Forms.DataVisualization.Charting.DateTimeIntervalType.Seconds;
            chartArea2.AxisX.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            chartArea2.AxisX.MajorGrid.Interval = 5D;
            chartArea2.AxisX.MajorGrid.IntervalType = System.Windows.Forms.DataVisualization.Charting.DateTimeIntervalType.Seconds;
            chartArea2.AxisX.MajorGrid.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            chartArea2.AxisX.MajorTickMark.Interval = 5D;
            chartArea2.AxisX.MajorTickMark.IntervalType = System.Windows.Forms.DataVisualization.Charting.DateTimeIntervalType.Seconds;
            chartArea2.AxisX.ScrollBar.ButtonColor = System.Drawing.Color.Silver;
            chartArea2.AxisX.ScrollBar.LineColor = System.Drawing.Color.Lime;
            chartArea2.AxisX.ScrollBar.Size = 15D;
            chartArea2.AxisY.IsLabelAutoFit = false;
            chartArea2.AxisY.IsStartedFromZero = false;
            chartArea2.AxisY.LabelStyle.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold);
            chartArea2.AxisY.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            chartArea2.AxisY.MajorGrid.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            chartArea2.AxisY.Maximum = 10D;
            chartArea2.AxisY.Minimum = 0D;
            chartArea2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(165)))), ((int)(((byte)(191)))), ((int)(((byte)(228)))));
            chartArea2.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.TopBottom;
            chartArea2.BackSecondaryColor = System.Drawing.Color.White;
            chartArea2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            chartArea2.BorderDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid;
            chartArea2.Name = "Default";
            chartArea2.Position.Auto = false;
            chartArea2.Position.Height = 86.76062F;
            chartArea2.Position.Width = 88F;
            chartArea2.Position.X = 5.089137F;
            chartArea2.Position.Y = 5.895753F;
            chartArea2.ShadowColor = System.Drawing.Color.Transparent;
            this.chart1.ChartAreas.Add(chartArea2);
            legend2.Alignment = System.Drawing.StringAlignment.Far;
            legend2.BackColor = System.Drawing.Color.Transparent;
            legend2.DockedToChartArea = "Default";
            legend2.Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Top;
            legend2.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold);
            legend2.IsTextAutoFit = false;
            legend2.LegendStyle = System.Windows.Forms.DataVisualization.Charting.LegendStyle.Row;
            legend2.Name = "Default";
            this.chart1.Legends.Add(legend2);
            this.chart1.Location = new System.Drawing.Point(20, 420);
            this.chart1.Name = "chart1";
            series2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(26)))), ((int)(((byte)(59)))), ((int)(((byte)(105)))));
            series2.ChartArea = "Default";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(64)))), ((int)(((byte)(10)))));
            series2.Legend = "Default";
            series2.Name = "Sensor 1";
            series2.ShadowOffset = 1;
            this.chart1.Series.Add(series2);
            this.chart1.Size = new System.Drawing.Size(1098, 326);
            this.chart1.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox2.Controls.Add(this.portconnect);
            this.groupBox2.Controls.Add(this.portname);
            this.groupBox2.Location = new System.Drawing.Point(1125, 420);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(176, 116);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Port Setting";
            // 
            // portconnect
            // 
            this.portconnect.Location = new System.Drawing.Point(7, 66);
            this.portconnect.Margin = new System.Windows.Forms.Padding(4);
            this.portconnect.Name = "portconnect";
            this.portconnect.Size = new System.Drawing.Size(157, 28);
            this.portconnect.TabIndex = 5;
            this.portconnect.Text = "Open Port";
            this.portconnect.UseVisualStyleBackColor = true;
            this.portconnect.Click += new System.EventHandler(this.portconnect_Click);
            // 
            // portname
            // 
            this.portname.FormattingEnabled = true;
            this.portname.Location = new System.Drawing.Point(7, 28);
            this.portname.Margin = new System.Windows.Forms.Padding(4);
            this.portname.Name = "portname";
            this.portname.Size = new System.Drawing.Size(160, 24);
            this.portname.TabIndex = 4;
            this.portname.Text = "COM3";
            this.portname.DragDrop += new System.Windows.Forms.DragEventHandler(this.portname_DragDrop);
            // 
            // serialPort1
            // 
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort1_DataReceived);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 500;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.configuraçãoToolStripMenuItem,
            this.sobreToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(8, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1316, 28);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(73, 24);
            this.fileToolStripMenuItem.Text = "Arquivo";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(109, 26);
            this.exitToolStripMenuItem.Text = "Sair";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // configuraçãoToolStripMenuItem
            // 
            this.configuraçãoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fichaTécnicaToolStripMenuItem,
            this.comunicaçãoToolStripMenuItem,
            this.aferiçaçãoDeVazãoToolStripMenuItem});
            this.configuraçãoToolStripMenuItem.Name = "configuraçãoToolStripMenuItem";
            this.configuraçãoToolStripMenuItem.Size = new System.Drawing.Size(110, 24);
            this.configuraçãoToolStripMenuItem.Text = "Configuração";
            // 
            // fichaTécnicaToolStripMenuItem
            // 
            this.fichaTécnicaToolStripMenuItem.Name = "fichaTécnicaToolStripMenuItem";
            this.fichaTécnicaToolStripMenuItem.Size = new System.Drawing.Size(174, 26);
            this.fichaTécnicaToolStripMenuItem.Text = "Ficha Técnica";
            this.fichaTécnicaToolStripMenuItem.Click += new System.EventHandler(this.fichaTécnicaToolStripMenuItem_Click);
            // 
            // comunicaçãoToolStripMenuItem
            // 
            this.comunicaçãoToolStripMenuItem.Name = "comunicaçãoToolStripMenuItem";
            this.comunicaçãoToolStripMenuItem.Size = new System.Drawing.Size(174, 26);
            this.comunicaçãoToolStripMenuItem.Text = "Comunicação";
            this.comunicaçãoToolStripMenuItem.Click += new System.EventHandler(this.comunicaçãoToolStripMenuItem_Click);
            // 
            // sobreToolStripMenuItem
            // 
            this.sobreToolStripMenuItem.Name = "sobreToolStripMenuItem";
            this.sobreToolStripMenuItem.Size = new System.Drawing.Size(60, 24);
            this.sobreToolStripMenuItem.Text = "Sobre";
            this.sobreToolStripMenuItem.Click += new System.EventHandler(this.sobreToolStripMenuItem_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.GroupTeste);
            this.panel1.Controls.Add(this.groupBox5);
            this.panel1.Controls.Add(this.GroupMaster);
            this.panel1.Location = new System.Drawing.Point(16, 33);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1285, 379);
            this.panel1.TabIndex = 5;
            // 
            // GroupTeste
            // 
            this.GroupTeste.Controls.Add(this.groupBox3);
            this.GroupTeste.Controls.Add(this.Vazao_T100);
            this.GroupTeste.Controls.Add(this.Pres_T100);
            this.GroupTeste.Controls.Add(this.Temp_T100);
            this.GroupTeste.Controls.Add(this.Pulso_Tot_T100);
            this.GroupTeste.Controls.Add(this.Vol_Tot_T100);
            this.GroupTeste.Controls.Add(this.Pulso_Min_T100);
            this.GroupTeste.Controls.Add(this.Vazao_T70);
            this.GroupTeste.Controls.Add(this.Pres_T70);
            this.GroupTeste.Controls.Add(this.Temp_T70);
            this.GroupTeste.Controls.Add(this.Pulso_Tot_T70);
            this.GroupTeste.Controls.Add(this.Vol_Tot_T70);
            this.GroupTeste.Controls.Add(this.Pulso_Min_T70);
            this.GroupTeste.Controls.Add(this.Vazao_T50);
            this.GroupTeste.Controls.Add(this.Pres_T50);
            this.GroupTeste.Controls.Add(this.Temp_T50);
            this.GroupTeste.Controls.Add(this.Pulso_Tot_T50);
            this.GroupTeste.Controls.Add(this.Vol_Tot_T50);
            this.GroupTeste.Controls.Add(this.Pulso_Min_T50);
            this.GroupTeste.Controls.Add(this.Vazao_T30);
            this.GroupTeste.Controls.Add(this.Pres_T30);
            this.GroupTeste.Controls.Add(this.Temp_T30);
            this.GroupTeste.Controls.Add(this.Pulso_Tot_T30);
            this.GroupTeste.Controls.Add(this.Vol_Tot_T30);
            this.GroupTeste.Controls.Add(this.Pulso_Min_T30);
            this.GroupTeste.Controls.Add(this.Vazao_T20);
            this.GroupTeste.Controls.Add(this.Pres_T20);
            this.GroupTeste.Controls.Add(this.Temp_T20);
            this.GroupTeste.Controls.Add(this.Pulso_Tot_T20);
            this.GroupTeste.Controls.Add(this.Vol_Tot_T20);
            this.GroupTeste.Controls.Add(this.Pulso_Min_T20);
            this.GroupTeste.Controls.Add(this.label11);
            this.GroupTeste.Controls.Add(this.Fator_T100);
            this.GroupTeste.Controls.Add(this.label12);
            this.GroupTeste.Controls.Add(this.label13);
            this.GroupTeste.Controls.Add(this.label14);
            this.GroupTeste.Controls.Add(this.label18);
            this.GroupTeste.Controls.Add(this.Fator_T70);
            this.GroupTeste.Controls.Add(this.Fator_T50);
            this.GroupTeste.Controls.Add(this.Fator_T30);
            this.GroupTeste.Controls.Add(this.Fator_T20);
            this.GroupTeste.Controls.Add(this.Vazao_T10);
            this.GroupTeste.Controls.Add(this.Pres_T10);
            this.GroupTeste.Controls.Add(this.Temp_T10);
            this.GroupTeste.Controls.Add(this.Pulso_Tot_T10);
            this.GroupTeste.Controls.Add(this.Vol_Tot_T10);
            this.GroupTeste.Controls.Add(this.Pulso_Min_T10);
            this.GroupTeste.Controls.Add(this.Fator_T10);
            this.GroupTeste.Controls.Add(this.label19);
            this.GroupTeste.Location = new System.Drawing.Point(807, 22);
            this.GroupTeste.Margin = new System.Windows.Forms.Padding(4);
            this.GroupTeste.Name = "GroupTeste";
            this.GroupTeste.Padding = new System.Windows.Forms.Padding(4);
            this.GroupTeste.Size = new System.Drawing.Size(464, 357);
            this.GroupTeste.TabIndex = 68;
            this.GroupTeste.TabStop = false;
            this.GroupTeste.Text = "Turbina Teste";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label32);
            this.groupBox3.Controls.Add(this.Volume);
            this.groupBox3.Location = new System.Drawing.Point(11, 290);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(440, 57);
            this.groupBox3.TabIndex = 68;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Critério de Parada";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(23, 28);
            this.label32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(125, 17);
            this.label32.TabIndex = 4;
            this.label32.Text = "Volume da Corrida";
            this.label32.Click += new System.EventHandler(this.label32_Click);
            // 
            // Volume
            // 
            this.Volume.Location = new System.Drawing.Point(166, 25);
            this.Volume.Margin = new System.Windows.Forms.Padding(4);
            this.Volume.Name = "Volume";
            this.Volume.Size = new System.Drawing.Size(80, 22);
            this.Volume.TabIndex = 3;
            this.Volume.Text = "0";
            this.Volume.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Vazao_T100
            // 
            this.Vazao_T100.Location = new System.Drawing.Point(384, 252);
            this.Vazao_T100.Margin = new System.Windows.Forms.Padding(4);
            this.Vazao_T100.Name = "Vazao_T100";
            this.Vazao_T100.Size = new System.Drawing.Size(65, 22);
            this.Vazao_T100.TabIndex = 67;
            this.Vazao_T100.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pres_T100
            // 
            this.Pres_T100.Location = new System.Drawing.Point(384, 220);
            this.Pres_T100.Margin = new System.Windows.Forms.Padding(4);
            this.Pres_T100.Name = "Pres_T100";
            this.Pres_T100.Size = new System.Drawing.Size(65, 22);
            this.Pres_T100.TabIndex = 66;
            this.Pres_T100.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Temp_T100
            // 
            this.Temp_T100.Location = new System.Drawing.Point(384, 188);
            this.Temp_T100.Margin = new System.Windows.Forms.Padding(4);
            this.Temp_T100.Name = "Temp_T100";
            this.Temp_T100.Size = new System.Drawing.Size(65, 22);
            this.Temp_T100.TabIndex = 65;
            this.Temp_T100.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pulso_Tot_T100
            // 
            this.Pulso_Tot_T100.Location = new System.Drawing.Point(384, 154);
            this.Pulso_Tot_T100.Margin = new System.Windows.Forms.Padding(4);
            this.Pulso_Tot_T100.Name = "Pulso_Tot_T100";
            this.Pulso_Tot_T100.Size = new System.Drawing.Size(65, 22);
            this.Pulso_Tot_T100.TabIndex = 64;
            this.Pulso_Tot_T100.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Vol_Tot_T100
            // 
            this.Vol_Tot_T100.Location = new System.Drawing.Point(384, 122);
            this.Vol_Tot_T100.Margin = new System.Windows.Forms.Padding(4);
            this.Vol_Tot_T100.Name = "Vol_Tot_T100";
            this.Vol_Tot_T100.Size = new System.Drawing.Size(65, 22);
            this.Vol_Tot_T100.TabIndex = 63;
            this.Vol_Tot_T100.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pulso_Min_T100
            // 
            this.Pulso_Min_T100.Location = new System.Drawing.Point(384, 90);
            this.Pulso_Min_T100.Margin = new System.Windows.Forms.Padding(4);
            this.Pulso_Min_T100.Name = "Pulso_Min_T100";
            this.Pulso_Min_T100.Size = new System.Drawing.Size(65, 22);
            this.Pulso_Min_T100.TabIndex = 62;
            this.Pulso_Min_T100.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Vazao_T70
            // 
            this.Vazao_T70.Location = new System.Drawing.Point(309, 252);
            this.Vazao_T70.Margin = new System.Windows.Forms.Padding(4);
            this.Vazao_T70.Name = "Vazao_T70";
            this.Vazao_T70.Size = new System.Drawing.Size(65, 22);
            this.Vazao_T70.TabIndex = 61;
            this.Vazao_T70.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pres_T70
            // 
            this.Pres_T70.Location = new System.Drawing.Point(309, 220);
            this.Pres_T70.Margin = new System.Windows.Forms.Padding(4);
            this.Pres_T70.Name = "Pres_T70";
            this.Pres_T70.Size = new System.Drawing.Size(65, 22);
            this.Pres_T70.TabIndex = 60;
            this.Pres_T70.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Temp_T70
            // 
            this.Temp_T70.Location = new System.Drawing.Point(309, 188);
            this.Temp_T70.Margin = new System.Windows.Forms.Padding(4);
            this.Temp_T70.Name = "Temp_T70";
            this.Temp_T70.Size = new System.Drawing.Size(65, 22);
            this.Temp_T70.TabIndex = 59;
            this.Temp_T70.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pulso_Tot_T70
            // 
            this.Pulso_Tot_T70.Location = new System.Drawing.Point(309, 154);
            this.Pulso_Tot_T70.Margin = new System.Windows.Forms.Padding(4);
            this.Pulso_Tot_T70.Name = "Pulso_Tot_T70";
            this.Pulso_Tot_T70.Size = new System.Drawing.Size(65, 22);
            this.Pulso_Tot_T70.TabIndex = 58;
            this.Pulso_Tot_T70.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Vol_Tot_T70
            // 
            this.Vol_Tot_T70.Location = new System.Drawing.Point(309, 122);
            this.Vol_Tot_T70.Margin = new System.Windows.Forms.Padding(4);
            this.Vol_Tot_T70.Name = "Vol_Tot_T70";
            this.Vol_Tot_T70.Size = new System.Drawing.Size(65, 22);
            this.Vol_Tot_T70.TabIndex = 57;
            this.Vol_Tot_T70.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pulso_Min_T70
            // 
            this.Pulso_Min_T70.Location = new System.Drawing.Point(309, 90);
            this.Pulso_Min_T70.Margin = new System.Windows.Forms.Padding(4);
            this.Pulso_Min_T70.Name = "Pulso_Min_T70";
            this.Pulso_Min_T70.Size = new System.Drawing.Size(65, 22);
            this.Pulso_Min_T70.TabIndex = 56;
            this.Pulso_Min_T70.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Vazao_T50
            // 
            this.Vazao_T50.Location = new System.Drawing.Point(235, 252);
            this.Vazao_T50.Margin = new System.Windows.Forms.Padding(4);
            this.Vazao_T50.Name = "Vazao_T50";
            this.Vazao_T50.Size = new System.Drawing.Size(65, 22);
            this.Vazao_T50.TabIndex = 55;
            this.Vazao_T50.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pres_T50
            // 
            this.Pres_T50.Location = new System.Drawing.Point(235, 220);
            this.Pres_T50.Margin = new System.Windows.Forms.Padding(4);
            this.Pres_T50.Name = "Pres_T50";
            this.Pres_T50.Size = new System.Drawing.Size(65, 22);
            this.Pres_T50.TabIndex = 54;
            this.Pres_T50.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Temp_T50
            // 
            this.Temp_T50.Location = new System.Drawing.Point(235, 188);
            this.Temp_T50.Margin = new System.Windows.Forms.Padding(4);
            this.Temp_T50.Name = "Temp_T50";
            this.Temp_T50.Size = new System.Drawing.Size(65, 22);
            this.Temp_T50.TabIndex = 53;
            this.Temp_T50.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pulso_Tot_T50
            // 
            this.Pulso_Tot_T50.Location = new System.Drawing.Point(235, 154);
            this.Pulso_Tot_T50.Margin = new System.Windows.Forms.Padding(4);
            this.Pulso_Tot_T50.Name = "Pulso_Tot_T50";
            this.Pulso_Tot_T50.Size = new System.Drawing.Size(65, 22);
            this.Pulso_Tot_T50.TabIndex = 52;
            this.Pulso_Tot_T50.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Vol_Tot_T50
            // 
            this.Vol_Tot_T50.Location = new System.Drawing.Point(235, 122);
            this.Vol_Tot_T50.Margin = new System.Windows.Forms.Padding(4);
            this.Vol_Tot_T50.Name = "Vol_Tot_T50";
            this.Vol_Tot_T50.Size = new System.Drawing.Size(65, 22);
            this.Vol_Tot_T50.TabIndex = 51;
            this.Vol_Tot_T50.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pulso_Min_T50
            // 
            this.Pulso_Min_T50.Location = new System.Drawing.Point(235, 90);
            this.Pulso_Min_T50.Margin = new System.Windows.Forms.Padding(4);
            this.Pulso_Min_T50.Name = "Pulso_Min_T50";
            this.Pulso_Min_T50.Size = new System.Drawing.Size(65, 22);
            this.Pulso_Min_T50.TabIndex = 50;
            this.Pulso_Min_T50.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Vazao_T30
            // 
            this.Vazao_T30.Location = new System.Drawing.Point(160, 252);
            this.Vazao_T30.Margin = new System.Windows.Forms.Padding(4);
            this.Vazao_T30.Name = "Vazao_T30";
            this.Vazao_T30.Size = new System.Drawing.Size(65, 22);
            this.Vazao_T30.TabIndex = 49;
            this.Vazao_T30.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pres_T30
            // 
            this.Pres_T30.Location = new System.Drawing.Point(160, 220);
            this.Pres_T30.Margin = new System.Windows.Forms.Padding(4);
            this.Pres_T30.Name = "Pres_T30";
            this.Pres_T30.Size = new System.Drawing.Size(65, 22);
            this.Pres_T30.TabIndex = 48;
            this.Pres_T30.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Temp_T30
            // 
            this.Temp_T30.Location = new System.Drawing.Point(160, 188);
            this.Temp_T30.Margin = new System.Windows.Forms.Padding(4);
            this.Temp_T30.Name = "Temp_T30";
            this.Temp_T30.Size = new System.Drawing.Size(65, 22);
            this.Temp_T30.TabIndex = 47;
            this.Temp_T30.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pulso_Tot_T30
            // 
            this.Pulso_Tot_T30.Location = new System.Drawing.Point(160, 154);
            this.Pulso_Tot_T30.Margin = new System.Windows.Forms.Padding(4);
            this.Pulso_Tot_T30.Name = "Pulso_Tot_T30";
            this.Pulso_Tot_T30.Size = new System.Drawing.Size(65, 22);
            this.Pulso_Tot_T30.TabIndex = 46;
            this.Pulso_Tot_T30.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Vol_Tot_T30
            // 
            this.Vol_Tot_T30.Location = new System.Drawing.Point(160, 122);
            this.Vol_Tot_T30.Margin = new System.Windows.Forms.Padding(4);
            this.Vol_Tot_T30.Name = "Vol_Tot_T30";
            this.Vol_Tot_T30.Size = new System.Drawing.Size(65, 22);
            this.Vol_Tot_T30.TabIndex = 45;
            this.Vol_Tot_T30.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pulso_Min_T30
            // 
            this.Pulso_Min_T30.Location = new System.Drawing.Point(160, 90);
            this.Pulso_Min_T30.Margin = new System.Windows.Forms.Padding(4);
            this.Pulso_Min_T30.Name = "Pulso_Min_T30";
            this.Pulso_Min_T30.Size = new System.Drawing.Size(65, 22);
            this.Pulso_Min_T30.TabIndex = 44;
            this.Pulso_Min_T30.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Vazao_T20
            // 
            this.Vazao_T20.Location = new System.Drawing.Point(85, 252);
            this.Vazao_T20.Margin = new System.Windows.Forms.Padding(4);
            this.Vazao_T20.Name = "Vazao_T20";
            this.Vazao_T20.Size = new System.Drawing.Size(65, 22);
            this.Vazao_T20.TabIndex = 43;
            this.Vazao_T20.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pres_T20
            // 
            this.Pres_T20.Location = new System.Drawing.Point(85, 220);
            this.Pres_T20.Margin = new System.Windows.Forms.Padding(4);
            this.Pres_T20.Name = "Pres_T20";
            this.Pres_T20.Size = new System.Drawing.Size(65, 22);
            this.Pres_T20.TabIndex = 42;
            this.Pres_T20.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Temp_T20
            // 
            this.Temp_T20.Location = new System.Drawing.Point(85, 188);
            this.Temp_T20.Margin = new System.Windows.Forms.Padding(4);
            this.Temp_T20.Name = "Temp_T20";
            this.Temp_T20.Size = new System.Drawing.Size(65, 22);
            this.Temp_T20.TabIndex = 41;
            this.Temp_T20.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pulso_Tot_T20
            // 
            this.Pulso_Tot_T20.Location = new System.Drawing.Point(85, 154);
            this.Pulso_Tot_T20.Margin = new System.Windows.Forms.Padding(4);
            this.Pulso_Tot_T20.Name = "Pulso_Tot_T20";
            this.Pulso_Tot_T20.Size = new System.Drawing.Size(65, 22);
            this.Pulso_Tot_T20.TabIndex = 40;
            this.Pulso_Tot_T20.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Vol_Tot_T20
            // 
            this.Vol_Tot_T20.Location = new System.Drawing.Point(85, 122);
            this.Vol_Tot_T20.Margin = new System.Windows.Forms.Padding(4);
            this.Vol_Tot_T20.Name = "Vol_Tot_T20";
            this.Vol_Tot_T20.Size = new System.Drawing.Size(65, 22);
            this.Vol_Tot_T20.TabIndex = 39;
            this.Vol_Tot_T20.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pulso_Min_T20
            // 
            this.Pulso_Min_T20.Location = new System.Drawing.Point(85, 90);
            this.Pulso_Min_T20.Margin = new System.Windows.Forms.Padding(4);
            this.Pulso_Min_T20.Name = "Pulso_Min_T20";
            this.Pulso_Min_T20.Size = new System.Drawing.Size(65, 22);
            this.Pulso_Min_T20.TabIndex = 38;
            this.Pulso_Min_T20.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label11.Location = new System.Drawing.Point(384, 25);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.MinimumSize = new System.Drawing.Size(66, 2);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(66, 19);
            this.label11.TabIndex = 37;
            this.label11.Text = "100%";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Fator_T100
            // 
            this.Fator_T100.Location = new System.Drawing.Point(384, 58);
            this.Fator_T100.Margin = new System.Windows.Forms.Padding(4);
            this.Fator_T100.Name = "Fator_T100";
            this.Fator_T100.Size = new System.Drawing.Size(65, 22);
            this.Fator_T100.TabIndex = 36;
            this.Fator_T100.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label12.Location = new System.Drawing.Point(309, 25);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.MinimumSize = new System.Drawing.Size(66, 2);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(66, 19);
            this.label12.TabIndex = 35;
            this.label12.Text = "70%";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label13.Location = new System.Drawing.Point(235, 25);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.MinimumSize = new System.Drawing.Size(66, 2);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(66, 19);
            this.label13.TabIndex = 34;
            this.label13.Text = "50%";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label14.Location = new System.Drawing.Point(160, 25);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.MinimumSize = new System.Drawing.Size(66, 2);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(66, 19);
            this.label14.TabIndex = 33;
            this.label14.Text = "30%";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label18.Location = new System.Drawing.Point(85, 25);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.MinimumSize = new System.Drawing.Size(66, 2);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(66, 19);
            this.label18.TabIndex = 32;
            this.label18.Text = "20%";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Fator_T70
            // 
            this.Fator_T70.Location = new System.Drawing.Point(309, 58);
            this.Fator_T70.Margin = new System.Windows.Forms.Padding(4);
            this.Fator_T70.Name = "Fator_T70";
            this.Fator_T70.Size = new System.Drawing.Size(65, 22);
            this.Fator_T70.TabIndex = 31;
            this.Fator_T70.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Fator_T50
            // 
            this.Fator_T50.Location = new System.Drawing.Point(235, 58);
            this.Fator_T50.Margin = new System.Windows.Forms.Padding(4);
            this.Fator_T50.Name = "Fator_T50";
            this.Fator_T50.Size = new System.Drawing.Size(65, 22);
            this.Fator_T50.TabIndex = 30;
            this.Fator_T50.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Fator_T30
            // 
            this.Fator_T30.Location = new System.Drawing.Point(160, 58);
            this.Fator_T30.Margin = new System.Windows.Forms.Padding(4);
            this.Fator_T30.Name = "Fator_T30";
            this.Fator_T30.Size = new System.Drawing.Size(65, 22);
            this.Fator_T30.TabIndex = 29;
            this.Fator_T30.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Fator_T20
            // 
            this.Fator_T20.Location = new System.Drawing.Point(85, 58);
            this.Fator_T20.Margin = new System.Windows.Forms.Padding(4);
            this.Fator_T20.Name = "Fator_T20";
            this.Fator_T20.Size = new System.Drawing.Size(65, 22);
            this.Fator_T20.TabIndex = 28;
            this.Fator_T20.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Vazao_T10
            // 
            this.Vazao_T10.Location = new System.Drawing.Point(11, 252);
            this.Vazao_T10.Margin = new System.Windows.Forms.Padding(4);
            this.Vazao_T10.Name = "Vazao_T10";
            this.Vazao_T10.Size = new System.Drawing.Size(65, 22);
            this.Vazao_T10.TabIndex = 27;
            this.Vazao_T10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pres_T10
            // 
            this.Pres_T10.Location = new System.Drawing.Point(11, 220);
            this.Pres_T10.Margin = new System.Windows.Forms.Padding(4);
            this.Pres_T10.Name = "Pres_T10";
            this.Pres_T10.Size = new System.Drawing.Size(65, 22);
            this.Pres_T10.TabIndex = 26;
            this.Pres_T10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Temp_T10
            // 
            this.Temp_T10.Location = new System.Drawing.Point(11, 188);
            this.Temp_T10.Margin = new System.Windows.Forms.Padding(4);
            this.Temp_T10.Name = "Temp_T10";
            this.Temp_T10.Size = new System.Drawing.Size(65, 22);
            this.Temp_T10.TabIndex = 25;
            this.Temp_T10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pulso_Tot_T10
            // 
            this.Pulso_Tot_T10.Location = new System.Drawing.Point(11, 154);
            this.Pulso_Tot_T10.Margin = new System.Windows.Forms.Padding(4);
            this.Pulso_Tot_T10.Name = "Pulso_Tot_T10";
            this.Pulso_Tot_T10.Size = new System.Drawing.Size(65, 22);
            this.Pulso_Tot_T10.TabIndex = 21;
            this.Pulso_Tot_T10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Vol_Tot_T10
            // 
            this.Vol_Tot_T10.Location = new System.Drawing.Point(11, 122);
            this.Vol_Tot_T10.Margin = new System.Windows.Forms.Padding(4);
            this.Vol_Tot_T10.Name = "Vol_Tot_T10";
            this.Vol_Tot_T10.Size = new System.Drawing.Size(65, 22);
            this.Vol_Tot_T10.TabIndex = 19;
            this.Vol_Tot_T10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pulso_Min_T10
            // 
            this.Pulso_Min_T10.Location = new System.Drawing.Point(11, 90);
            this.Pulso_Min_T10.Margin = new System.Windows.Forms.Padding(4);
            this.Pulso_Min_T10.Name = "Pulso_Min_T10";
            this.Pulso_Min_T10.Size = new System.Drawing.Size(65, 22);
            this.Pulso_Min_T10.TabIndex = 17;
            this.Pulso_Min_T10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Fator_T10
            // 
            this.Fator_T10.Location = new System.Drawing.Point(11, 58);
            this.Fator_T10.Margin = new System.Windows.Forms.Padding(4);
            this.Fator_T10.Name = "Fator_T10";
            this.Fator_T10.Size = new System.Drawing.Size(65, 22);
            this.Fator_T10.TabIndex = 14;
            this.Fator_T10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label19.Location = new System.Drawing.Point(11, 25);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.MinimumSize = new System.Drawing.Size(66, 2);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(66, 19);
            this.label19.TabIndex = 0;
            this.label19.Text = "10%";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.Restante);
            this.groupBox5.Controls.Add(this.Vazao_T);
            this.groupBox5.Controls.Add(this.label27);
            this.groupBox5.Controls.Add(this.label26);
            this.groupBox5.Controls.Add(this.Pres_T);
            this.groupBox5.Controls.Add(this.Temp_T);
            this.groupBox5.Controls.Add(this.Pulso_Tot_T);
            this.groupBox5.Controls.Add(this.Vol_Tot_T);
            this.groupBox5.Controls.Add(this.Pulso_Min_T);
            this.groupBox5.Controls.Add(this.Fator_T);
            this.groupBox5.Controls.Add(this.btnTransfer);
            this.groupBox5.Controls.Add(this.btnStop);
            this.groupBox5.Controls.Add(this.btnStart);
            this.groupBox5.Controls.Add(this.Percentual);
            this.groupBox5.Controls.Add(this.Vazao_M);
            this.groupBox5.Controls.Add(this.Pres_M);
            this.groupBox5.Controls.Add(this.Temp_M);
            this.groupBox5.Controls.Add(this.label7);
            this.groupBox5.Controls.Add(this.label8);
            this.groupBox5.Controls.Add(this.label15);
            this.groupBox5.Controls.Add(this.Pulso_Tot_M);
            this.groupBox5.Controls.Add(this.label9);
            this.groupBox5.Controls.Add(this.Vol_Tot_M);
            this.groupBox5.Controls.Add(this.label10);
            this.groupBox5.Controls.Add(this.Pulso_Min_M);
            this.groupBox5.Controls.Add(this.label16);
            this.groupBox5.Controls.Add(this.label17);
            this.groupBox5.Controls.Add(this.Fator_M);
            this.groupBox5.Location = new System.Drawing.Point(4, 22);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox5.Size = new System.Drawing.Size(323, 353);
            this.groupBox5.TabIndex = 10;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Itens";
            // 
            // Restante
            // 
            this.Restante.Location = new System.Drawing.Point(215, 320);
            this.Restante.Margin = new System.Windows.Forms.Padding(4);
            this.Restante.Name = "Restante";
            this.Restante.Size = new System.Drawing.Size(99, 22);
            this.Restante.TabIndex = 27;
            // 
            // Vazao_T
            // 
            this.Vazao_T.Location = new System.Drawing.Point(227, 252);
            this.Vazao_T.Margin = new System.Windows.Forms.Padding(4);
            this.Vazao_T.Name = "Vazao_T";
            this.Vazao_T.Size = new System.Drawing.Size(65, 22);
            this.Vazao_T.TabIndex = 26;
            this.Vazao_T.Text = "0";
            this.Vazao_T.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(233, 32);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(44, 17);
            this.label27.TabIndex = 25;
            this.label27.Text = "Teste";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(153, 32);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(51, 17);
            this.label26.TabIndex = 24;
            this.label26.Text = "Master";
            // 
            // Pres_T
            // 
            this.Pres_T.Location = new System.Drawing.Point(227, 220);
            this.Pres_T.Margin = new System.Windows.Forms.Padding(4);
            this.Pres_T.Name = "Pres_T";
            this.Pres_T.Size = new System.Drawing.Size(65, 22);
            this.Pres_T.TabIndex = 23;
            this.Pres_T.Text = "0";
            this.Pres_T.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Temp_T
            // 
            this.Temp_T.Location = new System.Drawing.Point(227, 188);
            this.Temp_T.Margin = new System.Windows.Forms.Padding(4);
            this.Temp_T.Name = "Temp_T";
            this.Temp_T.Size = new System.Drawing.Size(65, 22);
            this.Temp_T.TabIndex = 22;
            this.Temp_T.Text = "0";
            this.Temp_T.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pulso_Tot_T
            // 
            this.Pulso_Tot_T.Location = new System.Drawing.Point(227, 154);
            this.Pulso_Tot_T.Margin = new System.Windows.Forms.Padding(4);
            this.Pulso_Tot_T.Name = "Pulso_Tot_T";
            this.Pulso_Tot_T.Size = new System.Drawing.Size(65, 22);
            this.Pulso_Tot_T.TabIndex = 21;
            this.Pulso_Tot_T.Text = "0";
            this.Pulso_Tot_T.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Vol_Tot_T
            // 
            this.Vol_Tot_T.Location = new System.Drawing.Point(227, 122);
            this.Vol_Tot_T.Margin = new System.Windows.Forms.Padding(4);
            this.Vol_Tot_T.Name = "Vol_Tot_T";
            this.Vol_Tot_T.Size = new System.Drawing.Size(65, 22);
            this.Vol_Tot_T.TabIndex = 20;
            this.Vol_Tot_T.Text = "0";
            this.Vol_Tot_T.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pulso_Min_T
            // 
            this.Pulso_Min_T.Location = new System.Drawing.Point(227, 90);
            this.Pulso_Min_T.Margin = new System.Windows.Forms.Padding(4);
            this.Pulso_Min_T.Name = "Pulso_Min_T";
            this.Pulso_Min_T.Size = new System.Drawing.Size(65, 22);
            this.Pulso_Min_T.TabIndex = 19;
            this.Pulso_Min_T.Text = "0";
            this.Pulso_Min_T.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Fator_T
            // 
            this.Fator_T.Location = new System.Drawing.Point(227, 58);
            this.Fator_T.Margin = new System.Windows.Forms.Padding(4);
            this.Fator_T.Name = "Fator_T";
            this.Fator_T.Size = new System.Drawing.Size(65, 22);
            this.Fator_T.TabIndex = 18;
            this.Fator_T.Text = "1";
            this.Fator_T.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.Fator_T.Validating += new System.ComponentModel.CancelEventHandler(this.Fator_T_Validating);
            // 
            // btnTransfer
            // 
            this.btnTransfer.Location = new System.Drawing.Point(20, 286);
            this.btnTransfer.Margin = new System.Windows.Forms.Padding(4);
            this.btnTransfer.Name = "btnTransfer";
            this.btnTransfer.Size = new System.Drawing.Size(117, 25);
            this.btnTransfer.TabIndex = 17;
            this.btnTransfer.Text = "Transferir";
            this.btnTransfer.UseVisualStyleBackColor = true;
            this.btnTransfer.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnStop
            // 
            this.btnStop.Location = new System.Drawing.Point(112, 319);
            this.btnStop.Margin = new System.Windows.Forms.Padding(4);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(93, 25);
            this.btnStop.TabIndex = 16;
            this.btnStop.Text = "Stop";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(20, 319);
            this.btnStart.Margin = new System.Windows.Forms.Padding(4);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(72, 25);
            this.btnStart.TabIndex = 15;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // Percentual
            // 
            this.Percentual.FormattingEnabled = true;
            this.Percentual.Items.AddRange(new object[] {
            "10 %",
            "20 %",
            "30 %",
            "50 %",
            "70 %",
            "100 %"});
            this.Percentual.Location = new System.Drawing.Point(148, 284);
            this.Percentual.Margin = new System.Windows.Forms.Padding(4);
            this.Percentual.Name = "Percentual";
            this.Percentual.Size = new System.Drawing.Size(65, 24);
            this.Percentual.TabIndex = 14;
            // 
            // Vazao_M
            // 
            this.Vazao_M.Location = new System.Drawing.Point(148, 252);
            this.Vazao_M.Margin = new System.Windows.Forms.Padding(4);
            this.Vazao_M.Name = "Vazao_M";
            this.Vazao_M.Size = new System.Drawing.Size(65, 22);
            this.Vazao_M.TabIndex = 13;
            this.Vazao_M.Text = "0";
            this.Vazao_M.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pres_M
            // 
            this.Pres_M.Location = new System.Drawing.Point(148, 220);
            this.Pres_M.Margin = new System.Windows.Forms.Padding(4);
            this.Pres_M.Name = "Pres_M";
            this.Pres_M.Size = new System.Drawing.Size(65, 22);
            this.Pres_M.TabIndex = 12;
            this.Pres_M.Text = "0";
            this.Pres_M.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Temp_M
            // 
            this.Temp_M.Location = new System.Drawing.Point(148, 188);
            this.Temp_M.Margin = new System.Windows.Forms.Padding(4);
            this.Temp_M.Name = "Temp_M";
            this.Temp_M.Size = new System.Drawing.Size(65, 22);
            this.Temp_M.TabIndex = 11;
            this.Temp_M.Text = "0";
            this.Temp_M.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(16, 154);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(127, 17);
            this.label7.TabIndex = 10;
            this.label7.Text = "Pulsos Totalizados";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(16, 122);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(125, 17);
            this.label8.TabIndex = 9;
            this.label8.Text = "Volume Totalizado";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(16, 90);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(121, 17);
            this.label15.TabIndex = 8;
            this.label15.Text = "Pulsos por Minuto";
            // 
            // Pulso_Tot_M
            // 
            this.Pulso_Tot_M.Location = new System.Drawing.Point(148, 154);
            this.Pulso_Tot_M.Margin = new System.Windows.Forms.Padding(4);
            this.Pulso_Tot_M.Name = "Pulso_Tot_M";
            this.Pulso_Tot_M.Size = new System.Drawing.Size(65, 22);
            this.Pulso_Tot_M.TabIndex = 7;
            this.Pulso_Tot_M.Text = "0";
            this.Pulso_Tot_M.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(13, 252);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(83, 17);
            this.label9.TabIndex = 6;
            this.label9.Text = "Vazão m3/h";
            // 
            // Vol_Tot_M
            // 
            this.Vol_Tot_M.Location = new System.Drawing.Point(148, 122);
            this.Vol_Tot_M.Margin = new System.Windows.Forms.Padding(4);
            this.Vol_Tot_M.Name = "Vol_Tot_M";
            this.Vol_Tot_M.Size = new System.Drawing.Size(65, 22);
            this.Vol_Tot_M.TabIndex = 5;
            this.Vol_Tot_M.Text = "0";
            this.Vol_Tot_M.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(13, 220);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(60, 17);
            this.label10.TabIndex = 4;
            this.label10.Text = "Pressão";
            // 
            // Pulso_Min_M
            // 
            this.Pulso_Min_M.Location = new System.Drawing.Point(148, 90);
            this.Pulso_Min_M.Margin = new System.Windows.Forms.Padding(4);
            this.Pulso_Min_M.Name = "Pulso_Min_M";
            this.Pulso_Min_M.Size = new System.Drawing.Size(65, 22);
            this.Pulso_Min_M.TabIndex = 3;
            this.Pulso_Min_M.Text = "0";
            this.Pulso_Min_M.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(13, 188);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(90, 17);
            this.label16.TabIndex = 2;
            this.label16.Text = "Temperatura";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(16, 57);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(54, 17);
            this.label17.TabIndex = 1;
            this.label17.Text = "Fator K";
            // 
            // Fator_M
            // 
            this.Fator_M.Location = new System.Drawing.Point(148, 58);
            this.Fator_M.Margin = new System.Windows.Forms.Padding(4);
            this.Fator_M.Name = "Fator_M";
            this.Fator_M.Size = new System.Drawing.Size(65, 22);
            this.Fator_M.TabIndex = 0;
            this.Fator_M.Text = "1";
            this.Fator_M.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.Fator_M.Validating += new System.ComponentModel.CancelEventHandler(this.Fator_M_Validating);
            // 
            // GroupMaster
            // 
            this.GroupMaster.Controls.Add(this.Vazao_M100);
            this.GroupMaster.Controls.Add(this.Pres_M100);
            this.GroupMaster.Controls.Add(this.Temp_M100);
            this.GroupMaster.Controls.Add(this.Pulso_Tot_M100);
            this.GroupMaster.Controls.Add(this.Vol_Tot_M100);
            this.GroupMaster.Controls.Add(this.Pulso_Min_M100);
            this.GroupMaster.Controls.Add(this.Vazao_M70);
            this.GroupMaster.Controls.Add(this.Pres_M70);
            this.GroupMaster.Controls.Add(this.Temp_M70);
            this.GroupMaster.Controls.Add(this.Pulso_Tot_M70);
            this.GroupMaster.Controls.Add(this.Vol_Tot_M70);
            this.GroupMaster.Controls.Add(this.Pulso_Min_M70);
            this.GroupMaster.Controls.Add(this.Vazao_M50);
            this.GroupMaster.Controls.Add(this.Pres_M50);
            this.GroupMaster.Controls.Add(this.Temp_M50);
            this.GroupMaster.Controls.Add(this.Pulso_Tot_M50);
            this.GroupMaster.Controls.Add(this.Vol_Tot_M50);
            this.GroupMaster.Controls.Add(this.Pulso_Min_M50);
            this.GroupMaster.Controls.Add(this.Vazao_M30);
            this.GroupMaster.Controls.Add(this.Pres_M30);
            this.GroupMaster.Controls.Add(this.Temp_M30);
            this.GroupMaster.Controls.Add(this.Pulso_Tot_M30);
            this.GroupMaster.Controls.Add(this.Vol_Tot_M30);
            this.GroupMaster.Controls.Add(this.Pulso_Min_M30);
            this.GroupMaster.Controls.Add(this.Vazao_M20);
            this.GroupMaster.Controls.Add(this.Pres_M20);
            this.GroupMaster.Controls.Add(this.Temp_M20);
            this.GroupMaster.Controls.Add(this.Pulso_Tot_M20);
            this.GroupMaster.Controls.Add(this.Vol_Tot_M20);
            this.GroupMaster.Controls.Add(this.Pulso_Min_M20);
            this.GroupMaster.Controls.Add(this.label20);
            this.GroupMaster.Controls.Add(this.Fator_M100);
            this.GroupMaster.Controls.Add(this.label21);
            this.GroupMaster.Controls.Add(this.label22);
            this.GroupMaster.Controls.Add(this.label23);
            this.GroupMaster.Controls.Add(this.label24);
            this.GroupMaster.Controls.Add(this.Fator_M70);
            this.GroupMaster.Controls.Add(this.Fator_M50);
            this.GroupMaster.Controls.Add(this.Fator_M30);
            this.GroupMaster.Controls.Add(this.Fator_M20);
            this.GroupMaster.Controls.Add(this.Vazao_M10);
            this.GroupMaster.Controls.Add(this.Pres_M10);
            this.GroupMaster.Controls.Add(this.Temp_M10);
            this.GroupMaster.Controls.Add(this.Pulso_Tot_M10);
            this.GroupMaster.Controls.Add(this.Vol_Tot_M10);
            this.GroupMaster.Controls.Add(this.Pulso_Min_M10);
            this.GroupMaster.Controls.Add(this.Fator_M10);
            this.GroupMaster.Controls.Add(this.label25);
            this.GroupMaster.Location = new System.Drawing.Point(335, 22);
            this.GroupMaster.Margin = new System.Windows.Forms.Padding(4);
            this.GroupMaster.Name = "GroupMaster";
            this.GroupMaster.Padding = new System.Windows.Forms.Padding(4);
            this.GroupMaster.Size = new System.Drawing.Size(464, 353);
            this.GroupMaster.TabIndex = 9;
            this.GroupMaster.TabStop = false;
            this.GroupMaster.Text = "Turbina Master";
            // 
            // Vazao_M100
            // 
            this.Vazao_M100.Location = new System.Drawing.Point(384, 252);
            this.Vazao_M100.Margin = new System.Windows.Forms.Padding(4);
            this.Vazao_M100.Name = "Vazao_M100";
            this.Vazao_M100.Size = new System.Drawing.Size(65, 22);
            this.Vazao_M100.TabIndex = 67;
            this.Vazao_M100.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pres_M100
            // 
            this.Pres_M100.Location = new System.Drawing.Point(384, 220);
            this.Pres_M100.Margin = new System.Windows.Forms.Padding(4);
            this.Pres_M100.Name = "Pres_M100";
            this.Pres_M100.Size = new System.Drawing.Size(65, 22);
            this.Pres_M100.TabIndex = 66;
            this.Pres_M100.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Temp_M100
            // 
            this.Temp_M100.Location = new System.Drawing.Point(384, 188);
            this.Temp_M100.Margin = new System.Windows.Forms.Padding(4);
            this.Temp_M100.Name = "Temp_M100";
            this.Temp_M100.Size = new System.Drawing.Size(65, 22);
            this.Temp_M100.TabIndex = 65;
            this.Temp_M100.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pulso_Tot_M100
            // 
            this.Pulso_Tot_M100.Location = new System.Drawing.Point(384, 154);
            this.Pulso_Tot_M100.Margin = new System.Windows.Forms.Padding(4);
            this.Pulso_Tot_M100.Name = "Pulso_Tot_M100";
            this.Pulso_Tot_M100.Size = new System.Drawing.Size(65, 22);
            this.Pulso_Tot_M100.TabIndex = 64;
            this.Pulso_Tot_M100.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Vol_Tot_M100
            // 
            this.Vol_Tot_M100.Location = new System.Drawing.Point(384, 122);
            this.Vol_Tot_M100.Margin = new System.Windows.Forms.Padding(4);
            this.Vol_Tot_M100.Name = "Vol_Tot_M100";
            this.Vol_Tot_M100.Size = new System.Drawing.Size(65, 22);
            this.Vol_Tot_M100.TabIndex = 63;
            this.Vol_Tot_M100.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pulso_Min_M100
            // 
            this.Pulso_Min_M100.Location = new System.Drawing.Point(384, 90);
            this.Pulso_Min_M100.Margin = new System.Windows.Forms.Padding(4);
            this.Pulso_Min_M100.Name = "Pulso_Min_M100";
            this.Pulso_Min_M100.Size = new System.Drawing.Size(65, 22);
            this.Pulso_Min_M100.TabIndex = 62;
            this.Pulso_Min_M100.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Vazao_M70
            // 
            this.Vazao_M70.Location = new System.Drawing.Point(309, 252);
            this.Vazao_M70.Margin = new System.Windows.Forms.Padding(4);
            this.Vazao_M70.Name = "Vazao_M70";
            this.Vazao_M70.Size = new System.Drawing.Size(65, 22);
            this.Vazao_M70.TabIndex = 61;
            this.Vazao_M70.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pres_M70
            // 
            this.Pres_M70.Location = new System.Drawing.Point(309, 220);
            this.Pres_M70.Margin = new System.Windows.Forms.Padding(4);
            this.Pres_M70.Name = "Pres_M70";
            this.Pres_M70.Size = new System.Drawing.Size(65, 22);
            this.Pres_M70.TabIndex = 60;
            this.Pres_M70.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Temp_M70
            // 
            this.Temp_M70.Location = new System.Drawing.Point(309, 188);
            this.Temp_M70.Margin = new System.Windows.Forms.Padding(4);
            this.Temp_M70.Name = "Temp_M70";
            this.Temp_M70.Size = new System.Drawing.Size(65, 22);
            this.Temp_M70.TabIndex = 59;
            this.Temp_M70.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pulso_Tot_M70
            // 
            this.Pulso_Tot_M70.Location = new System.Drawing.Point(309, 154);
            this.Pulso_Tot_M70.Margin = new System.Windows.Forms.Padding(4);
            this.Pulso_Tot_M70.Name = "Pulso_Tot_M70";
            this.Pulso_Tot_M70.Size = new System.Drawing.Size(65, 22);
            this.Pulso_Tot_M70.TabIndex = 58;
            this.Pulso_Tot_M70.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Vol_Tot_M70
            // 
            this.Vol_Tot_M70.Location = new System.Drawing.Point(309, 122);
            this.Vol_Tot_M70.Margin = new System.Windows.Forms.Padding(4);
            this.Vol_Tot_M70.Name = "Vol_Tot_M70";
            this.Vol_Tot_M70.Size = new System.Drawing.Size(65, 22);
            this.Vol_Tot_M70.TabIndex = 57;
            this.Vol_Tot_M70.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pulso_Min_M70
            // 
            this.Pulso_Min_M70.Location = new System.Drawing.Point(309, 90);
            this.Pulso_Min_M70.Margin = new System.Windows.Forms.Padding(4);
            this.Pulso_Min_M70.Name = "Pulso_Min_M70";
            this.Pulso_Min_M70.Size = new System.Drawing.Size(65, 22);
            this.Pulso_Min_M70.TabIndex = 56;
            this.Pulso_Min_M70.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Vazao_M50
            // 
            this.Vazao_M50.Location = new System.Drawing.Point(235, 252);
            this.Vazao_M50.Margin = new System.Windows.Forms.Padding(4);
            this.Vazao_M50.Name = "Vazao_M50";
            this.Vazao_M50.Size = new System.Drawing.Size(65, 22);
            this.Vazao_M50.TabIndex = 55;
            this.Vazao_M50.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pres_M50
            // 
            this.Pres_M50.Location = new System.Drawing.Point(235, 220);
            this.Pres_M50.Margin = new System.Windows.Forms.Padding(4);
            this.Pres_M50.Name = "Pres_M50";
            this.Pres_M50.Size = new System.Drawing.Size(65, 22);
            this.Pres_M50.TabIndex = 54;
            this.Pres_M50.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Temp_M50
            // 
            this.Temp_M50.Location = new System.Drawing.Point(235, 188);
            this.Temp_M50.Margin = new System.Windows.Forms.Padding(4);
            this.Temp_M50.Name = "Temp_M50";
            this.Temp_M50.Size = new System.Drawing.Size(65, 22);
            this.Temp_M50.TabIndex = 53;
            this.Temp_M50.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pulso_Tot_M50
            // 
            this.Pulso_Tot_M50.Location = new System.Drawing.Point(235, 154);
            this.Pulso_Tot_M50.Margin = new System.Windows.Forms.Padding(4);
            this.Pulso_Tot_M50.Name = "Pulso_Tot_M50";
            this.Pulso_Tot_M50.Size = new System.Drawing.Size(65, 22);
            this.Pulso_Tot_M50.TabIndex = 52;
            this.Pulso_Tot_M50.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Vol_Tot_M50
            // 
            this.Vol_Tot_M50.Location = new System.Drawing.Point(235, 122);
            this.Vol_Tot_M50.Margin = new System.Windows.Forms.Padding(4);
            this.Vol_Tot_M50.Name = "Vol_Tot_M50";
            this.Vol_Tot_M50.Size = new System.Drawing.Size(65, 22);
            this.Vol_Tot_M50.TabIndex = 51;
            this.Vol_Tot_M50.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pulso_Min_M50
            // 
            this.Pulso_Min_M50.Location = new System.Drawing.Point(235, 90);
            this.Pulso_Min_M50.Margin = new System.Windows.Forms.Padding(4);
            this.Pulso_Min_M50.Name = "Pulso_Min_M50";
            this.Pulso_Min_M50.Size = new System.Drawing.Size(65, 22);
            this.Pulso_Min_M50.TabIndex = 50;
            this.Pulso_Min_M50.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Vazao_M30
            // 
            this.Vazao_M30.Location = new System.Drawing.Point(160, 252);
            this.Vazao_M30.Margin = new System.Windows.Forms.Padding(4);
            this.Vazao_M30.Name = "Vazao_M30";
            this.Vazao_M30.Size = new System.Drawing.Size(65, 22);
            this.Vazao_M30.TabIndex = 49;
            this.Vazao_M30.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pres_M30
            // 
            this.Pres_M30.Location = new System.Drawing.Point(160, 220);
            this.Pres_M30.Margin = new System.Windows.Forms.Padding(4);
            this.Pres_M30.Name = "Pres_M30";
            this.Pres_M30.Size = new System.Drawing.Size(65, 22);
            this.Pres_M30.TabIndex = 48;
            this.Pres_M30.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Temp_M30
            // 
            this.Temp_M30.Location = new System.Drawing.Point(160, 188);
            this.Temp_M30.Margin = new System.Windows.Forms.Padding(4);
            this.Temp_M30.Name = "Temp_M30";
            this.Temp_M30.Size = new System.Drawing.Size(65, 22);
            this.Temp_M30.TabIndex = 47;
            this.Temp_M30.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pulso_Tot_M30
            // 
            this.Pulso_Tot_M30.Location = new System.Drawing.Point(160, 154);
            this.Pulso_Tot_M30.Margin = new System.Windows.Forms.Padding(4);
            this.Pulso_Tot_M30.Name = "Pulso_Tot_M30";
            this.Pulso_Tot_M30.Size = new System.Drawing.Size(65, 22);
            this.Pulso_Tot_M30.TabIndex = 46;
            this.Pulso_Tot_M30.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Vol_Tot_M30
            // 
            this.Vol_Tot_M30.Location = new System.Drawing.Point(160, 122);
            this.Vol_Tot_M30.Margin = new System.Windows.Forms.Padding(4);
            this.Vol_Tot_M30.Name = "Vol_Tot_M30";
            this.Vol_Tot_M30.Size = new System.Drawing.Size(65, 22);
            this.Vol_Tot_M30.TabIndex = 45;
            this.Vol_Tot_M30.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pulso_Min_M30
            // 
            this.Pulso_Min_M30.Location = new System.Drawing.Point(160, 90);
            this.Pulso_Min_M30.Margin = new System.Windows.Forms.Padding(4);
            this.Pulso_Min_M30.Name = "Pulso_Min_M30";
            this.Pulso_Min_M30.Size = new System.Drawing.Size(65, 22);
            this.Pulso_Min_M30.TabIndex = 44;
            this.Pulso_Min_M30.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Vazao_M20
            // 
            this.Vazao_M20.Location = new System.Drawing.Point(85, 252);
            this.Vazao_M20.Margin = new System.Windows.Forms.Padding(4);
            this.Vazao_M20.Name = "Vazao_M20";
            this.Vazao_M20.Size = new System.Drawing.Size(65, 22);
            this.Vazao_M20.TabIndex = 43;
            this.Vazao_M20.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pres_M20
            // 
            this.Pres_M20.Location = new System.Drawing.Point(85, 220);
            this.Pres_M20.Margin = new System.Windows.Forms.Padding(4);
            this.Pres_M20.Name = "Pres_M20";
            this.Pres_M20.Size = new System.Drawing.Size(65, 22);
            this.Pres_M20.TabIndex = 42;
            this.Pres_M20.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Temp_M20
            // 
            this.Temp_M20.Location = new System.Drawing.Point(85, 188);
            this.Temp_M20.Margin = new System.Windows.Forms.Padding(4);
            this.Temp_M20.Name = "Temp_M20";
            this.Temp_M20.Size = new System.Drawing.Size(65, 22);
            this.Temp_M20.TabIndex = 41;
            this.Temp_M20.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pulso_Tot_M20
            // 
            this.Pulso_Tot_M20.Location = new System.Drawing.Point(85, 154);
            this.Pulso_Tot_M20.Margin = new System.Windows.Forms.Padding(4);
            this.Pulso_Tot_M20.Name = "Pulso_Tot_M20";
            this.Pulso_Tot_M20.Size = new System.Drawing.Size(65, 22);
            this.Pulso_Tot_M20.TabIndex = 40;
            this.Pulso_Tot_M20.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Vol_Tot_M20
            // 
            this.Vol_Tot_M20.Location = new System.Drawing.Point(85, 122);
            this.Vol_Tot_M20.Margin = new System.Windows.Forms.Padding(4);
            this.Vol_Tot_M20.Name = "Vol_Tot_M20";
            this.Vol_Tot_M20.Size = new System.Drawing.Size(65, 22);
            this.Vol_Tot_M20.TabIndex = 39;
            this.Vol_Tot_M20.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pulso_Min_M20
            // 
            this.Pulso_Min_M20.Location = new System.Drawing.Point(85, 90);
            this.Pulso_Min_M20.Margin = new System.Windows.Forms.Padding(4);
            this.Pulso_Min_M20.Name = "Pulso_Min_M20";
            this.Pulso_Min_M20.Size = new System.Drawing.Size(65, 22);
            this.Pulso_Min_M20.TabIndex = 38;
            this.Pulso_Min_M20.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label20.Location = new System.Drawing.Point(384, 25);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.MinimumSize = new System.Drawing.Size(66, 2);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(66, 19);
            this.label20.TabIndex = 37;
            this.label20.Text = "100%";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Fator_M100
            // 
            this.Fator_M100.Location = new System.Drawing.Point(384, 58);
            this.Fator_M100.Margin = new System.Windows.Forms.Padding(4);
            this.Fator_M100.Name = "Fator_M100";
            this.Fator_M100.Size = new System.Drawing.Size(65, 22);
            this.Fator_M100.TabIndex = 36;
            this.Fator_M100.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label21.Location = new System.Drawing.Point(309, 25);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.MinimumSize = new System.Drawing.Size(66, 2);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(66, 19);
            this.label21.TabIndex = 35;
            this.label21.Text = "70%";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label22.Location = new System.Drawing.Point(235, 25);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.MinimumSize = new System.Drawing.Size(66, 2);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(66, 19);
            this.label22.TabIndex = 34;
            this.label22.Text = "50%";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label23.Location = new System.Drawing.Point(160, 25);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.MinimumSize = new System.Drawing.Size(66, 2);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(66, 19);
            this.label23.TabIndex = 33;
            this.label23.Text = "30%";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label24.Location = new System.Drawing.Point(85, 25);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.MinimumSize = new System.Drawing.Size(66, 2);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(66, 19);
            this.label24.TabIndex = 32;
            this.label24.Text = "20%";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Fator_M70
            // 
            this.Fator_M70.Location = new System.Drawing.Point(309, 58);
            this.Fator_M70.Margin = new System.Windows.Forms.Padding(4);
            this.Fator_M70.Name = "Fator_M70";
            this.Fator_M70.Size = new System.Drawing.Size(65, 22);
            this.Fator_M70.TabIndex = 31;
            this.Fator_M70.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Fator_M50
            // 
            this.Fator_M50.Location = new System.Drawing.Point(235, 58);
            this.Fator_M50.Margin = new System.Windows.Forms.Padding(4);
            this.Fator_M50.Name = "Fator_M50";
            this.Fator_M50.Size = new System.Drawing.Size(65, 22);
            this.Fator_M50.TabIndex = 30;
            this.Fator_M50.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Fator_M30
            // 
            this.Fator_M30.Location = new System.Drawing.Point(160, 58);
            this.Fator_M30.Margin = new System.Windows.Forms.Padding(4);
            this.Fator_M30.Name = "Fator_M30";
            this.Fator_M30.Size = new System.Drawing.Size(65, 22);
            this.Fator_M30.TabIndex = 29;
            this.Fator_M30.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Fator_M20
            // 
            this.Fator_M20.Location = new System.Drawing.Point(85, 58);
            this.Fator_M20.Margin = new System.Windows.Forms.Padding(4);
            this.Fator_M20.Name = "Fator_M20";
            this.Fator_M20.Size = new System.Drawing.Size(65, 22);
            this.Fator_M20.TabIndex = 28;
            this.Fator_M20.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Vazao_M10
            // 
            this.Vazao_M10.Location = new System.Drawing.Point(11, 252);
            this.Vazao_M10.Margin = new System.Windows.Forms.Padding(4);
            this.Vazao_M10.Name = "Vazao_M10";
            this.Vazao_M10.Size = new System.Drawing.Size(65, 22);
            this.Vazao_M10.TabIndex = 27;
            this.Vazao_M10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pres_M10
            // 
            this.Pres_M10.Location = new System.Drawing.Point(11, 220);
            this.Pres_M10.Margin = new System.Windows.Forms.Padding(4);
            this.Pres_M10.Name = "Pres_M10";
            this.Pres_M10.Size = new System.Drawing.Size(65, 22);
            this.Pres_M10.TabIndex = 26;
            this.Pres_M10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Temp_M10
            // 
            this.Temp_M10.Location = new System.Drawing.Point(11, 188);
            this.Temp_M10.Margin = new System.Windows.Forms.Padding(4);
            this.Temp_M10.Name = "Temp_M10";
            this.Temp_M10.Size = new System.Drawing.Size(65, 22);
            this.Temp_M10.TabIndex = 25;
            this.Temp_M10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pulso_Tot_M10
            // 
            this.Pulso_Tot_M10.Location = new System.Drawing.Point(11, 154);
            this.Pulso_Tot_M10.Margin = new System.Windows.Forms.Padding(4);
            this.Pulso_Tot_M10.Name = "Pulso_Tot_M10";
            this.Pulso_Tot_M10.Size = new System.Drawing.Size(65, 22);
            this.Pulso_Tot_M10.TabIndex = 21;
            this.Pulso_Tot_M10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Vol_Tot_M10
            // 
            this.Vol_Tot_M10.Location = new System.Drawing.Point(11, 122);
            this.Vol_Tot_M10.Margin = new System.Windows.Forms.Padding(4);
            this.Vol_Tot_M10.Name = "Vol_Tot_M10";
            this.Vol_Tot_M10.Size = new System.Drawing.Size(65, 22);
            this.Vol_Tot_M10.TabIndex = 19;
            this.Vol_Tot_M10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Pulso_Min_M10
            // 
            this.Pulso_Min_M10.Location = new System.Drawing.Point(11, 90);
            this.Pulso_Min_M10.Margin = new System.Windows.Forms.Padding(4);
            this.Pulso_Min_M10.Name = "Pulso_Min_M10";
            this.Pulso_Min_M10.Size = new System.Drawing.Size(65, 22);
            this.Pulso_Min_M10.TabIndex = 17;
            this.Pulso_Min_M10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Fator_M10
            // 
            this.Fator_M10.Location = new System.Drawing.Point(11, 58);
            this.Fator_M10.Margin = new System.Windows.Forms.Padding(4);
            this.Fator_M10.Name = "Fator_M10";
            this.Fator_M10.Size = new System.Drawing.Size(65, 22);
            this.Fator_M10.TabIndex = 14;
            this.Fator_M10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label25.Location = new System.Drawing.Point(11, 25);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.MinimumSize = new System.Drawing.Size(66, 2);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(66, 19);
            this.label25.TabIndex = 0;
            this.label25.Text = "10%";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // timer_parada
            // 
            this.timer_parada.Interval = 1000;
            this.timer_parada.Tick += new System.EventHandler(this.timer_parada_Tick);
            // 
            // timer_corrida
            // 
            this.timer_corrida.Interval = 1000;
            this.timer_corrida.Tick += new System.EventHandler(this.timer_corrida_Tick);
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.StatusLabel,
            this.TempoLabel});
            this.statusStrip1.Location = new System.Drawing.Point(0, 749);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1316, 25);
            this.statusStrip1.TabIndex = 70;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // StatusLabel
            // 
            this.StatusLabel.Name = "StatusLabel";
            this.StatusLabel.Size = new System.Drawing.Size(55, 20);
            this.StatusLabel.Text = "Ocioso";
            // 
            // TempoLabel
            // 
            this.TempoLabel.Name = "TempoLabel";
            this.TempoLabel.Size = new System.Drawing.Size(21, 20);
            this.TempoLabel.Text = "   ";
            // 
            // aferiçaçãoDeVazãoToolStripMenuItem
            // 
            this.aferiçaçãoDeVazãoToolStripMenuItem.Name = "aferiçaçãoDeVazãoToolStripMenuItem";
            this.aferiçaçãoDeVazãoToolStripMenuItem.Size = new System.Drawing.Size(220, 26);
            this.aferiçaçãoDeVazãoToolStripMenuItem.Text = "Aferiçação de Vazão";
            this.aferiçaçãoDeVazãoToolStripMenuItem.Click += new System.EventHandler(this.aferiçaçãoDeVazãoToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1316, 774);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.chart1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TurbinaCEG";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.GroupTeste.ResumeLayout(false);
            this.GroupTeste.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.GroupMaster.ResumeLayout(false);
            this.GroupMaster.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Chart chart1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox portname;
        private System.Windows.Forms.Button portconnect;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox GroupTeste;
        private System.Windows.Forms.TextBox Vazao_T100;
        private System.Windows.Forms.TextBox Pres_T100;
        private System.Windows.Forms.TextBox Temp_T100;
        private System.Windows.Forms.TextBox Pulso_Tot_T100;
        private System.Windows.Forms.TextBox Vol_Tot_T100;
        private System.Windows.Forms.TextBox Pulso_Min_T100;
        private System.Windows.Forms.TextBox Vazao_T70;
        private System.Windows.Forms.TextBox Pres_T70;
        private System.Windows.Forms.TextBox Temp_T70;
        private System.Windows.Forms.TextBox Pulso_Tot_T70;
        private System.Windows.Forms.TextBox Vol_Tot_T70;
        private System.Windows.Forms.TextBox Pulso_Min_T70;
        private System.Windows.Forms.TextBox Vazao_T50;
        private System.Windows.Forms.TextBox Pres_T50;
        private System.Windows.Forms.TextBox Temp_T50;
        private System.Windows.Forms.TextBox Pulso_Tot_T50;
        private System.Windows.Forms.TextBox Vol_Tot_T50;
        private System.Windows.Forms.TextBox Pulso_Min_T50;
        private System.Windows.Forms.TextBox Vazao_T30;
        private System.Windows.Forms.TextBox Pres_T30;
        private System.Windows.Forms.TextBox Temp_T30;
        private System.Windows.Forms.TextBox Pulso_Tot_T30;
        private System.Windows.Forms.TextBox Vol_Tot_T30;
        private System.Windows.Forms.TextBox Pulso_Min_T30;
        private System.Windows.Forms.TextBox Vazao_T20;
        private System.Windows.Forms.TextBox Pres_T20;
        private System.Windows.Forms.TextBox Temp_T20;
        private System.Windows.Forms.TextBox Pulso_Tot_T20;
        private System.Windows.Forms.TextBox Vol_Tot_T20;
        private System.Windows.Forms.TextBox Pulso_Min_T20;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox Fator_T100;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox Fator_T70;
        private System.Windows.Forms.TextBox Fator_T50;
        private System.Windows.Forms.TextBox Fator_T30;
        private System.Windows.Forms.TextBox Fator_T20;
        private System.Windows.Forms.TextBox Vazao_T10;
        private System.Windows.Forms.TextBox Pres_T10;
        private System.Windows.Forms.TextBox Temp_T10;
        private System.Windows.Forms.TextBox Pulso_Tot_T10;
        private System.Windows.Forms.TextBox Vol_Tot_T10;
        private System.Windows.Forms.TextBox Pulso_Min_T10;
        private System.Windows.Forms.TextBox Fator_T10;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button btnTransfer;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.ComboBox Percentual;
        private System.Windows.Forms.TextBox Vazao_M;
        private System.Windows.Forms.TextBox Pres_M;
        private System.Windows.Forms.TextBox Temp_M;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox Pulso_Tot_M;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox Vol_Tot_M;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox Pulso_Min_M;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox Fator_M;
        private System.Windows.Forms.GroupBox GroupMaster;
        private System.Windows.Forms.TextBox Vazao_M100;
        private System.Windows.Forms.TextBox Pres_M100;
        private System.Windows.Forms.TextBox Temp_M100;
        private System.Windows.Forms.TextBox Pulso_Tot_M100;
        private System.Windows.Forms.TextBox Vol_Tot_M100;
        private System.Windows.Forms.TextBox Pulso_Min_M100;
        private System.Windows.Forms.TextBox Vazao_M70;
        private System.Windows.Forms.TextBox Pres_M70;
        private System.Windows.Forms.TextBox Temp_M70;
        private System.Windows.Forms.TextBox Pulso_Tot_M70;
        private System.Windows.Forms.TextBox Vol_Tot_M70;
        private System.Windows.Forms.TextBox Pulso_Min_M70;
        private System.Windows.Forms.TextBox Vazao_M50;
        private System.Windows.Forms.TextBox Pres_M50;
        private System.Windows.Forms.TextBox Temp_M50;
        private System.Windows.Forms.TextBox Pulso_Tot_M50;
        private System.Windows.Forms.TextBox Vol_Tot_M50;
        private System.Windows.Forms.TextBox Pulso_Min_M50;
        private System.Windows.Forms.TextBox Vazao_M30;
        private System.Windows.Forms.TextBox Pres_M30;
        private System.Windows.Forms.TextBox Temp_M30;
        private System.Windows.Forms.TextBox Pulso_Tot_M30;
        private System.Windows.Forms.TextBox Vol_Tot_M30;
        private System.Windows.Forms.TextBox Pulso_Min_M30;
        private System.Windows.Forms.TextBox Vazao_M20;
        private System.Windows.Forms.TextBox Pres_M20;
        private System.Windows.Forms.TextBox Temp_M20;
        private System.Windows.Forms.TextBox Pulso_Tot_M20;
        private System.Windows.Forms.TextBox Vol_Tot_M20;
        private System.Windows.Forms.TextBox Pulso_Min_M20;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox Fator_M100;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox Fator_M70;
        private System.Windows.Forms.TextBox Fator_M50;
        private System.Windows.Forms.TextBox Fator_M30;
        private System.Windows.Forms.TextBox Fator_M20;
        private System.Windows.Forms.TextBox Vazao_M10;
        private System.Windows.Forms.TextBox Pres_M10;
        private System.Windows.Forms.TextBox Temp_M10;
        private System.Windows.Forms.TextBox Pulso_Tot_M10;
        private System.Windows.Forms.TextBox Vol_Tot_M10;
        private System.Windows.Forms.TextBox Pulso_Min_M10;
        private System.Windows.Forms.TextBox Fator_M10;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox Pres_T;
        private System.Windows.Forms.TextBox Temp_T;
        private System.Windows.Forms.TextBox Pulso_Tot_T;
        private System.Windows.Forms.TextBox Vol_Tot_T;
        private System.Windows.Forms.TextBox Pulso_Min_T;
        private System.Windows.Forms.TextBox Fator_T;
        private System.Windows.Forms.TextBox Vazao_T;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox Volume;
        private System.Windows.Forms.Timer timer_parada;
        private System.Windows.Forms.TextBox Restante;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Timer timer_corrida;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel StatusLabel;
        private System.Windows.Forms.ToolStripStatusLabel TempoLabel;
        private System.Windows.Forms.ToolStripMenuItem configuraçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fichaTécnicaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sobreToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem comunicaçãoToolStripMenuItem;
        private ToolStripMenuItem aferiçaçãoDeVazãoToolStripMenuItem;
    }
}

